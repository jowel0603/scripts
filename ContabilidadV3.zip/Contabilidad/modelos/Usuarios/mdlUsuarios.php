<?php
	require_once '../../conexion/conexion.php';

class ModeloUsuarios{

	/*=============================================
	MOSTRAR USUARIOS
	=============================================*/

    public function verificarUsuariologin($users,$clave){

			$database = new Connection();
        	$db = $database->open();


			$stmt = $db->prepare("SELECT  u.id, u.nombre, u.usuario, u.password, u.idrol, u.estado, r.idrol, r.nombre_rol 
				FROM usuarios u 
				INNER JOIN roles r ON u.idrol = r.idrol
			 WHERE u.usuario = :usuario and u.password = :password ");

			
		    $stmt -> bindParam(":usuario", $users, PDO::PARAM_STR);
            $stmt -> bindParam(":password", $clave, PDO::PARAM_STR);

			$stmt->execute();

			return $stmt;



		

		$stmt -> close();

		$stmt = null;


	}

	public function Cerrar_Seccion()
	{
		if(isset($_SESSION['nombre']) )
		{
		   echo "hay Session ";
		}
		elseif(!isset($_SESSION['nombre']) )
		{
			session_start();
			session_destroy();
		    session_unset();
			echo "<script type='text/javascript'> alert('SISTEMA CERRADO Satisfactoriamente!!!  ');
			window.location='../../vistas/index.php';</script>";
		}
		else
		{
			echo "todavia vivo ";
		}

        
    }



	/*=============================================
	EDITAR USUARIO
	=============================================*/

	static public function mdlEditarUsuario($tabla, $datos){
	
		$stmt = Conexion::conectar()->prepare("UPDATE $tabla SET nombre = :nombre, password = :password, perfil = :perfil, foto = :foto WHERE usuario = :usuario");

		$stmt -> bindParam(":nombre", $datos["nombre"], PDO::PARAM_STR);
		$stmt -> bindParam(":password", $datos["password"], PDO::PARAM_STR);
		$stmt -> bindParam(":perfil", $datos["perfil"], PDO::PARAM_STR);
		$stmt -> bindParam(":foto", $datos["foto"], PDO::PARAM_STR);
		$stmt -> bindParam(":usuario", $datos["usuario"], PDO::PARAM_STR);

		if($stmt -> execute()){

			return "ok";
		
		}else{

			return "error";	

		}

		$stmt -> close();

		$stmt = null;

	}

	/*=============================================
	ACTUALIZAR USUARIO
	=============================================*/

	static public function mdlActualizarUsuario($tabla, $item1, $valor1, $item2, $valor2){

		$stmt = Conexion::conectar()->prepare("UPDATE $tabla SET $item1 = :$item1 WHERE $item2 = :$item2");

		$stmt -> bindParam(":".$item1, $valor1, PDO::PARAM_STR);
		$stmt -> bindParam(":".$item2, $valor2, PDO::PARAM_STR);

		if($stmt -> execute()){

			return "ok";
		
		}else{

			return "error";	

		}

		$stmt -> close();

		$stmt = null;

	}

	/*=============================================
	BORRAR USUARIO
	=============================================*/

	static public function mdlBorrarUsuario($tabla, $datos){

		$stmt = Conexion::conectar()->prepare("DELETE FROM $tabla WHERE id = :id");

		$stmt -> bindParam(":id", $datos, PDO::PARAM_INT);

		if($stmt -> execute()){

			return "ok";
		
		}else{

			return "error";	

		}

		$stmt -> close();

		$stmt = null;


	}



	/*=============================================
	ROLES DE USUARIOS
	=============================================*/

	static public function mdlRoles(){

		$database = new Connection();
        $db = $database->open();

		$stmt = $db->prepare("SELECT * FROM roles");

		$stmt->execute();

		return $stmt -> fetchAll();
			

		$stmt -> close();

		$stmt = null;


	}

    /*=============================================
    Listar ROLES DE USUARIOS
    =============================================*/
    public function Listarroles(){
        try{

            $database = new Connection();
            $db = $database->open();

            $stmt = $db->prepare("SELECT * FROM roles");

            $stmt->execute();

            //hago return a la consulta
            return $stmt;


            //cierro conexion
            //
            $sql->closeCursor();
            $sql=null;
            $Ejecuta_Conexion->close();
            $Ejecuta_Conexion=null;

        }catch(Exception $e){
            echo 'Error al obtener modelo rol --> '.$e->getMessage();
        }catch(PDOException $ex){
            echo 'Error al conetener la conexion al modelo rol --> '.$ex->getMessage();
        }
    }



	/*=============================================
	LISTAR PERMISOS 
	=============================================*/
    public function listarpermisos(){

        try {

            $database = new Connection();
        	$db = $database->open();



            $sql=$db->prepare("SELECT * FROM tipo_permisos");
            $sql->execute();

             return $sql;


            $sql = null;
            $db = null;


        } catch (Exception $e) {
            echo "Error Al Obtener UsuarioModel -->  " . $e->getMessage();
        } catch (PDOException $ex) {
            echo "Erron Al UsuarioModel --> " . $ex->getMessage();
        }


       
    }

/*=============================================
	LISTAR PERMISOS MARCADOS O ASIGNADOS 
	=============================================*/
    public function listarmarcados($idusuario){

        try {

               
            $database = new Connection();
        	$db = $database->open();


            $sql=$db->prepare("SELECT * FROM permisos WHERE idusuario = :idusuario");
            $sql->execute(array(':idusuario' => $idusuario));


            return $sql;

            $sql->closeCursor();
            $sql = null;
           	$db = null;


            } catch (Exception $e) {
                echo "Error Al Obtener UsuarioModel -->  " . $e->getMessage();
            } catch (PDOException $ex) {
                echo "Erron En La Consulta --> " . $ex->getMessage();
            }
    }



	/*=============================================
	OBTENER $N_DOCUMENTO DE USUARIO PARA VALIDAR QUE NO INGRESE DUPLICADO
	=============================================*/
    public function getNumero($numero){

    	try {

            $database = new Connection();
        	$db = $database->open();



            $sql=$db->prepare("SELECT * FROM usuarios WHERE n_documento = :n_documento");
            $sql->execute(array(':n_documento' => $numero));

             return $sql;

            $sql->closeCursor();
            $sql = null;
            $db = null;


        } catch (Exception $e) {
            echo "Error Al Obtener UsuarioModel -->  " . $e->getMessage();
        } catch (PDOException $ex) {
            echo "Erron Al UsuarioModel --> " . $ex->getMessage();
        }


    }



    /*=============================================
	OBTENER $EMAIL DE USUARIO PARA VALIDAR QUE NO INGRESE DUPLICADO
	=============================================*/
    public function getEmail($email){

    	try {

            $database = new Connection();
        	$db = $database->open();



            $sql=$db->prepare("SELECT * FROM usuarios WHERE email = :email");
            $sql->execute(array(':email' => $email));

             return $sql;

            $sql->closeCursor();
            $sql = null;
            $db = null;


        } catch (Exception $e) {
            echo "Error Al Obtener UsuarioModel -->  " . $e->getMessage();
        } catch (PDOException $ex) {
            echo "Erron Al UsuarioModel --> " . $ex->getMessage();
        }


    }

     /*=============================================
	OBTENER $usuario DE USUARIO PARA VALIDAR QUE NO INGRESE DUPLICADO
	=============================================*/
    public function getUsuario($usuario){

    	try {

            $database = new Connection();
        	$db = $database->open();



            $sql=$db->prepare("SELECT * FROM usuarios WHERE usuario = :usuario");
            $sql->execute(array(':usuario' => $usuario));

             return $sql;

            $sql->closeCursor();
            $sql = null;
            $db = null;


        } catch (Exception $e) {
            echo "Error Al Obtener UsuarioModel -->  " . $e->getMessage();
        } catch (PDOException $ex) {
            echo "Erron Al UsuarioModel --> " . $ex->getMessage();
        }


    }

    /*=============================================
    OBTENER id DE USUARIO session para cambiar clave
    =============================================*/
    public function getUsuarioidSession($id){

        try {

            $database = new Connection();
            $db = $database->open();



            $sql=$db->prepare("SELECT * FROM usuarios WHERE id = :id");
            $sql->execute(array(':id' => $id));

             return $sql;

            $sql->closeCursor();
            $sql = null;
            $db = null;


        } catch (Exception $e) {
            echo "Error Al Obtener UsuarioModel -->  " . $e->getMessage();
        } catch (PDOException $ex) {
            echo "Erron Al UsuarioModel --> " . $ex->getMessage();
        }


    }




    /*=============================================
	OBTENER id usuario DE USUARIO PARA VALIDAR QUE NO INGRESE DUPLICADO
	=============================================*/
    public function getUsuarioId($id){

    	try {

            $database = new Connection();
        	$db = $database->open();



            $sql=$db->prepare("SELECT * FROM usuarios WHERE id = :id");
            $sql->execute(array(':id' => $id));

             return $sql;

            $sql->closeCursor();
            $sql = null;
            $db = null;


        } catch (Exception $e) {
            echo "Error Al Obtener UsuarioModel -->  " . $e->getMessage();
        } catch (PDOException $ex) {
            echo "Erron Al UsuarioModel --> " . $ex->getMessage();
        }


    }
     
     

    /*=============================================
	FUNCTION PARA REGISTRAR USUARIOS
	=============================================*/

    public function addUsuarios($nombre,$tipo_documento,$n_documento,$celular,$telefono,$email,$direccion,$usuario,$clave,$idrol,$estado,$idusuario,$fecha,$permiso){
    	try {

            $database = new Connection();
        	$db = $database->open();



            $sql = $db->prepare("INSERT INTO usuarios (nombre, tipodocumento, n_documento, celular, telefono, email, direccion, usuario, password, idrol, estado, idusuario, fecharegistro) VALUES(:nombre, :tipodocumento, :n_documento, :celular, :telefono, :email, :direccion, :usuario, :password, :idrol, :estado, :idusuario, :fecharegistro)");

            $sql->execute(array(':nombre' => $nombre, ':tipodocumento' => $tipo_documento, ':n_documento' => $n_documento, ':celular' => $celular, ':telefono' => $telefono, ':email' => $email, ':direccion' => $direccion, ':usuario' => $usuario, ':password' => $clave, ':idrol' => $idrol, ':estado' => $estado, ':idusuario' => $idusuario, ':fecharegistro' => $fecha));

            $idingresonew = $db->lastInsertId();

            $num_elementos=0;
            $sw=true;
            while ($num_elementos < count($permiso)) {

                $sql_detalle=$db->prepare("INSERT INTO permisos (idtipopermiso, idusuario, usuario, fecharegistro) VALUES(:idtipopermiso, :idusuario, :usuario, :fecharegistro)");
                $sql_detalle->execute(array(':idtipopermiso' => $permiso[$num_elementos],  ':idusuario' => $idingresonew,  ':usuario' => $idusuario, ':fecharegistro' => $fecha)) or $sw=false ;


                $num_elementos=$num_elementos+1;
            }
            
           

            if ($sql) {
                # code...
                return "ok";
            }else{
                return "error";
            }

            $sql = null;
            $db = null;


        } catch (Exception $e) {
            echo "Error Al Obtener UsuarioModel -->  " . $e->getMessage();
        } catch (PDOException $ex) {
            echo "Erron Al UsuarioModel --> " . $ex->getMessage();
        }
    }



    /*=============================================
	FUNCTION PARA EDITAR USUARIO SIN CLAVE
	=============================================*/
    public function editarUsuario($nombre,$tipo_documento,$num_documento,$celular,$telefono,$email,$direccion,$usuario,$cargo,$estado,$fecha,$permiso,$idusuarior,$idusuariow){
    	try {

            $database = new Connection();
        	$db = $database->open();



           #sql validar datos duplicados
                $sqlvalid = $db->prepare("SELECT * FROM usuarios WHERE email = :email and n_documento = :n_documento and usuario = :usuario");
                $sqlvalid->execute(array(':email' => $email, ':n_documento' => $num_documento, ':usuario' => $usuario));

                $num = $sqlvalid->rowCount();

                if ($num > 0) {
                    # code...
                    $sqldelete=$db->prepare("DELETE FROM permisos WHERE idusuario = :idusuario");
                    $sqldelete->execute(array(':idusuario' => $idusuariow));


                    #update a la tabla login
                    $sqladd=$db->prepare("UPDATE usuarios SET usuario = :usuario,  nombre = :nombre, direccion = :direccion, email = :email, telefono = :telefono, celular = :celular, tipodocumento = :tipodocumento, n_documento = :n_documento, idrol = :idrol, estado = :estado, usuario2 = :usuario2 , fechactualizado = :fechactualizado WHERE id = :id");
                    $sqladd->execute(array(':usuario' => $usuario, ':nombre' => $nombre, ':direccion' => $direccion, ':email' => $email, ':telefono' => $telefono, ':celular' => $celular, ':tipodocumento' => $tipo_documento, ':n_documento' => $num_documento, ':idrol' => $cargo, ':estado' => $estado, ':usuario2' => $idusuarior, ':fechactualizado' =>$fecha, ':id' => $idusuariow));

                    //obtengo el id usuario actualizado
                    $idingresonew = $db->lastInsertId();

                    if ($idingresonew !=null) {
                    # code...
                        for($i=0; $i<count($permiso); $i++){

                            $sql_detalle=$db->prepare("INSERT INTO permisos (idtipopermiso, idusuario, usuario, fecharegistro) VALUES(:idtipopermiso, :idusuario, :usuario, :fecharegistro)");
                            $sql_detalle->execute(array(':idtipopermiso' => $permiso[$i],  ':idusuario' => $idusuariow,  ':usuario' => $idusuarior, ':fecharegistro' => $fecha));


                        }
                    }

                    echo 0;

                    
                    
                }else{
                    echo  4;
                }

                
          

            $sqlvalid->closeCursor();
            $sqlvalid=null;
            $sql=null;
            $db=null;


        } catch (Exception $e) {
            echo "Error Al Obtener UsuarioModel -->  " . $e->getMessage();
        } catch (PDOException $ex) {
            echo "Erron Al UsuarioModel --> " . $ex->getMessage();
        }
    }



    /*=============================================
	FUNCTION PARA EDITAR USUARIO CON CLAVE
	=============================================*/
    public function editUsuario2($nombre,$tipo_documento,$num_documento,$celular,$telefono,$email,$direccion,$usuario,$clave2,$cargo,$estado,$fecha,$permiso,$idusuarior,$idusuariow){

    	try
        {

            $database = new Connection();
        	$db = $database->open();


            #sql validar datos duplicados
            $sqlvalid = $db->prepare("SELECT * FROM usuarios WHERE email = :email and n_documento = :n_documento and usuario = :usuario");
            $sqlvalid->execute(array(':email' => $email, ':n_documento' => $num_documento, ':usuario' => $usuario));


            $num = $sqlvalid->rowCount();

                if ($num > 0) {
                    # code...
                    $sqldelete=$db->prepare("DELETE FROM permisos WHERE idusuario = :idusuario");
                    $sqldelete->execute(array(':idusuario' => $idusuariow));
           

            
                    $sqladd=$db->prepare("UPDATE usuarios SET usuario = :usuario, password = :password, nombre = :nombre, direccion = :direccion, email = :email, telefono = :telefono, celular = :celular, tipodocumento = :tipodocumento, n_documento = :n_documento, idrol = :idrol, estado = :estado, usuario2 = :usuario2 , fechactualizado = :fechactualizado WHERE id = :id");
                        $sqladd->execute(array(':usuario' => $usuario, ':password' => $clave2, ':nombre' => $nombre, ':direccion' => $direccion, ':email' => $email, ':telefono' => $telefono, ':celular' => $celular, ':tipodocumento' => $tipo_documento, ':n_documento' => $num_documento, ':idrol' => $cargo, ':estado' => $estado, ':usuario2' => $idusuarior, ':fechactualizado' =>$fecha, ':id' => $idusuariow));

                     //obtengo el id usuario actualizado
                     $idingresonew = $db->lastInsertId();





                if ($idingresonew !=null) {
                # code...
                    for($i=0; $i<count($permiso); $i++){

                       $sql_detalle=$db->prepare("INSERT INTO permisos (idtipopermiso, idusuario, usuario, fecharegistro) VALUES(:idtipopermiso, :idusuario, :usuario, :fecharegistro)");
                       $sql_detalle->execute(array(':idtipopermiso' => $permiso[$i],  ':idusuario' => $idusuariow,  ':usuario' => $idusuarior, ':fecharegistro' => $fecha));




                    }
                }

                echo 2;




                }else{
                    echo  4;
                }

                




            $sqlvalid->closeCursor();
            $sqldelete=null;
            $sqlupdate=null;
            $sql_detalle=null;
            $db=null;


        }catch(Exception $ex){
            echo 'Erro al obtener modelo Usuario ---> '.$ex->getMessage();
        }catch(PDOException $ex){
            echo 'Error al conetener la conexion al modelo usuario --> '.$ex->getMessage();
        }

    }

    /*=============================================
    FUNCTION PARA EDITAR EL ESTADO USUARIO
    =============================================*/
    public function updateestado($id,$estado){
    	try {

            $database = new Connection();
        	$db = $database->open();


            $sql = $db->prepare("UPDATE usuarios SET estado = :estado  WHERE id = :id");
            $sql->execute(array(':estado' => $estado, ':id' => $id));




            return $sql;

            $sql = null;
            $db = null;
        } catch (Exception $e) {
            echo "Error Al Obtener UsuarioModel -->  " . $e->getMessage();
        } catch (PDOException $ex) {
            echo "Erron En La Consulta --> " . $ex->getMessage();
        }
    }





    /*=============================================
    FUNCTION PARA OBETENER USUARIO para validar CLAVE
    =============================================*/
    public function getClave($claveactual,$idusuario){
        try {

            $database = new Connection();
            $db = $database->open();


            $sql = $db->prepare("SELECT * FROM usuarios WHERE password = :password and id = :id LIMIT 1");
            $sql->execute(array(':password' => $claveactual, ':id' => $idusuario));




            return $sql;

            $sql = null;
            $db = null;
        } catch (Exception $e) {
            echo "Error Al Obtener UsuarioModel -->  " . $e->getMessage();
        } catch (PDOException $ex) {
            echo "Erron En La Consulta --> " . $ex->getMessage();
        }
    }


    /*=============================================
    FUNCTION PARA EDITAR CLAVE NUEVA
    =============================================*/
    public function updateClave($idusuario,$claveactual2){
        try {

            $database = new Connection();
            $db = $database->open();


            $sql = $db->prepare("UPDATE  usuarios SET password = :password WHERE id = :id ");
            $sql->execute(array(':password' => $claveactual2, ':id' => $idusuario));


            if ($sql) {
                # code...
                echo 1;
            }else{
                echo 2;
            }


            $sql = null;
            $db = null;
        } catch (Exception $e) {
            echo "Error Al Obtener UsuarioModel -->  " . $e->getMessage();
        } catch (PDOException $ex) {
            echo "Erron En La Consulta --> " . $ex->getMessage();
        }


        }
    



}