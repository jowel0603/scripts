<?php 

	require_once '../../conexion/conexion.php';
	class ModeloEmpresa{

	/*=============================================
	LISTADO DE EMPRESA
	=============================================*/
	public function Empresas($usuario){
		$database = new Connection();
        $db = $database->open();

        $stmt=$db->prepare("SELECT * FROM empresa WHERE idusuario = :idusuario");
        $stmt->execute(array(':idusuario' => $usuario));

        return $stmt -> fetchAll();



        $db->close();
        $stmt=null;
	}






	/*=============================================
	REGISTRO DE EMPRESA
	=============================================*/

	static public function mdlIngresarEmpresa($nombre,$ruc,$direccion,$telefono,$celular,$email,$idusuario,$fecha){

		$database = new Connection();
        $db = $database->open();

      
	        $stmt = $db->prepare("INSERT INTO empresa(nombre, nit, direccion, telefono, celular, correo, idusuario, fechaingreso) VALUES (:nombre, :nit, :direccion, :telefono, :celular, :correo, :idusuario, :fechaingreso)");
	        $stmt->execute(array(':nombre' => $nombre, ':nit' => $ruc, ':direccion' => $direccion, ':telefono' => $telefono, ':celular' => $celular, ':correo' => $email, ':idusuario' => $idusuario, ':fechaingreso' => $fecha));
	        


			if($stmt){

				return "ok";	

			}else{

				return "error";
			
			}
        

		

		
		
		$stmt = null;
		$db->close();

	}

	/*=============================================
	ACTUALIZAR DE EMPRESA
	=============================================*/
	public function mdlEditarempresa($nombre,$ruc,$direccion,$telefono,$celular,$email,$usuario,$idempresa){

		$database = new Connection();
        $db = $database->open();

            $sql=$db->prepare("SELECT * FROM empresa WHERE correo = :correo and  nit = :nit  ");
            $sql->execute(array(':correo' => $email, ':nit' => $ruc));

            if($sql->rowCount() > 0){

                $sql = $db->prepare("UPDATE empresa SET nombre = :nombre, nit = :nit, direccion = :direccion, telefono = :telefono, celular = :celular, correo = :correo, idusuario = :idusuario WHERE idempresa = :idempresa");

                $sql->execute(array(
                    ':nombre' => $nombre, ':nit' => $ruc, ':direccion' => $direccion, ':telefono' => $telefono,
                    ':celular' => $celular, ':correo' => $email, ':idusuario' => $usuario, ':idempresa' => $idempresa
                ));


                echo 'ok';
            }else{
                echo 'error2';
            }


           
            $sql->closeCursor();
            $sql=null;
            $db = null;
	}

	/*=============================================
	OBTENER DATOS DE EMPRESA
	=============================================*/
	public function getEmpresa($id){

		$database = new Connection();
        $db = $database->open();


		$sql = $db->prepare("SELECT * FROM empresa WHERE idempresa = :idempresa ");
		$sql->execute(array(':idempresa' => $id));


		return $sql->fetch();


		$sql->closeCursor();
        $db->close();

	}


	/*=============================================
	BUSCAR DATOS DE EMPRESA
	=============================================*/
	public function Buscarempresa($criterio){

		$database = new Connection();
        $db = $database->open();

//SELECT * FROM proveedor WHERE Nombre LIKE '%$criterio%' or documento LIKE '%$criterio%' ORDER BY Nombre LIMIT 8
		$sql = $db->prepare("SELECT * FROM empresa WHERE nombre LIKE '%$criterio%' or nit LIKE '%$criterio%' ORDER BY nombre LIMIT 8 ");
		$sql->execute();

        return $sql;



		$sql->closeCursor();
        $db=null;

	}


	/*=============================================
	CONSULTO QUE SI EXISTE O NO EL NIT  DE EMPRESA
	=============================================*/
	public function verificarnitempresa($valor){


		$database = new Connection();
        $db = $database->open();

        $sql = $db->prepare("SELECT * FROM empresa WHERE nit = :nit");
        $sql->execute(array(':nit' => $valor));

        return $sql;


        $stmt->closeCursor();
        $db->close();
	}


	/*=============================================
	CONSULTO QUE SI EXISTE O NO EL CORREO  DE EMPRESA
	=============================================*/
	public function verificarcorreoempresa($valor){


		$database = new Connection();
        $db = $database->open();

        $sql = $db->prepare("SELECT * FROM empresa WHERE correo = :correo");
        $sql->execute(array(':correo' => $valor));

        return $sql;


        $stmt->closeCursor();
        $db->close();
	}



	/*=============================================
	FUNCION CONFIGURACION EMPRESA SISTEMA
	=============================================*/
	public function mdlMostrarConigEmpresa(){

		try {

            $database = new Connection();
        	$db = $database->open();



            $sql=$db->prepare("SELECT * FROM configuracion_empresa LIMIT 1");
            $sql->execute();

             return $sql;


            $sql = null;
            $db = null;


        } catch (Exception $e) {
            echo "Error Al Obtener Empresa Model -->  " . $e->getMessage();
        } catch (PDOException $ex) {
            echo "Erron Al Empresa Model --> " . $ex->getMessage();
        }

	}

	/*=============================================
	FUNCION REGISTRAR CONFIGURACION EMPRESA SISTEMA
	=============================================*/
	public function mdlIngresarConfigDatos($nombre,$tipo_documento,$num_documento,$celular,$telefono,$email,$direccion,$usuario, $fecha){
		try {

            $database = new Connection();
        	$db = $database->open();

        	$sql = $db->prepare("INSERT INTO configuracion_empresa (nombre_empresa, tipodocumento, rut, telefono, celular, email, direccion, id_usuario, fecharegistro) VALUES (:nombre_empresa, :tipodocumento, :rut, :telefono, :celular, :email, :direccion, :id_usuario, :fecharegistro) ");

        	$sql->execute(array(':nombre_empresa' => $nombre, ':tipodocumento' => $tipo_documento, ':rut' => $num_documento, ':telefono' => $telefono, ':celular' => $celular, ':email' => $email, ':direccion' => $direccion, ':id_usuario' => $usuario, ':fecharegistro' => $fecha));

        	if ($sql) {
        		# code...
        		echo 1;
        	}else{
        		echo 2;
        	}


        	$sql=null;
        	$db=null;



        	} catch (Exception $e) {
            	echo "Error Al Obtener Empresa Model -->  " . $e->getMessage();
        	} catch (PDOException $ex) {
            	echo "Erron Al Empresa Model --> " . $ex->getMessage();
        	}
	}


	/*=============================================
	FUNCION REGISTRAR CONFIGURACION EMPRESA SISTEMA
	=============================================*/
	public function mdlIngresarConfigDatosEditar($nombre,$tipo_documento,$num_documento,$celular,$telefono,$email,$direccion,$usuario, $fecha, $idconfig){
		try {

            $database = new Connection();
        	$db = $database->open();

        	$sql = $db->prepare("UPDATE configuracion_empresa SET nombre_empresa = :nombre_empresa, tipodocumento = :tipodocumento, rut= :rut, telefono = :telefono, celular = :celular, email = :email,  direccion = :direccion, usuarioeditado = :usuarioeditado, fechactualizado = :fechactualizado WHERE idconfig = :idconfig ");

        	$sql->execute(array(':nombre_empresa' => $nombre, ':tipodocumento' => $tipo_documento, ':rut' => $num_documento, ':telefono' => $telefono, ':celular' => $celular, ':email' => $email, ':direccion' => $direccion, ':usuarioeditado' => $usuario, ':fechactualizado' => $fecha, ':idconfig' => $idconfig));

        	if ($sql) {
        		# code...
        		echo 1;
        	}else{
        		echo 2;
        	}


        	$sql=null;
        	$db=null;



        	} catch (Exception $e) {
            	echo "Error Al Obtener Empresa Model -->  " . $e->getMessage();
        	} catch (PDOException $ex) {
            	echo "Erron Al Empresa Model --> " . $ex->getMessage();
        	}
	}

	













	}













 ?>