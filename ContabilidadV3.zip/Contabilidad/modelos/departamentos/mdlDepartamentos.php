<?php 

	require_once '../../conexion/conexion.php';
	class ModeloDepartamento
	{


	/*=============================================
	LISTADO DE DEPARTAMENTO
	=============================================*/
	public function Departamento(){
		$database = new Connection();
        $db = $database->open();

        $stmt=$db->prepare("SELECT * FROM dptos");
        $stmt->execute();

        return $stmt -> fetchAll();



        $db->close();
        $stmt=null;
	}








	}

 ?>