<?php 

	require_once '../../conexion/conexion.php';
	class ModeloOcupacion
	{


	/*=============================================
	LISTADO DE OCUPACION
	=============================================*/
	public function Ocupacion(){
		$database = new Connection();
        $db = $database->open();

        $stmt=$db->prepare("SELECT * FROM ocupaciones");
        $stmt->execute();

        return $stmt -> fetchAll();



        $db->close();
        $stmt=null;
	}








	}

 ?>