<?php 

	require_once '../../conexion/conexion.php';
	class ModeloPension
	{


	/*=============================================
	LISTADO DE PENSION
	=============================================*/
	public function Pension($usuario){
		$database = new Connection();
        $db = $database->open();

        $stmt=$db->prepare("SELECT  s.idspension, s.codigo, s.nombre, s.valor, s.idempleado, s.idusuario, e.idempleado, e.nombres
        	FROM seguro_pension s 
            INNER JOIN empleados e 
            ON s.idempleado = e.idempleado WHERE s.idusuario = :idusuario");
        $stmt->execute(array(':idusuario' => $usuario));

        return $stmt -> fetchAll();



        $db->close();
        $stmt=null;
	}


	/*=============================================
	REGISTRO DE PENSION
	=============================================*/
	public function mdlIngresarpension($codigo, $nombre,$valor,$idempleado,$usuario, $fecha){
		$database = new Connection();
        $db = $database->open();

        $sql = $db->prepare("INSERT INTO  seguro_pension (codigo, nombre, valor, idempleado, idusuario, fecharegistro) VALUES(:codigo, :nombre, :valor, :idempleado, :idusuario, :fecharegistro)");
        $sql->execute(array(':codigo' => $codigo, ':nombre' => $nombre, ':valor' => $valor, ':idempleado' =>$idempleado, ':idusuario' => $usuario, ':fecharegistro' => $fecha));

        if ($sql) {
        	# code...
        	return 'ok';
        }else{
        	return 'error';
        }


        $db=null;
        $sql=null;

	}


	/*=============================================
	EDITAR  PENSION 
	=============================================*/
	public function mdlEditarpension($editarsueldo,$editid_ocup,$editaridusuario,$editidsueldo){

		$database = new Connection();
        $db = $database->open();

            $sql=$db->prepare("SELECT s.idocupacion, o.id_ocup FROM sueldos s INNER JOIN ocupaciones o ON s.idocupacion = o.id_ocup WHERE idocupacion = :idocupacion  ");
            $sql->execute(array(':idocupacion' => $editid_ocup));

            if($sql->rowCount() > 0){

                $sql = $db->prepare("UPDATE sueldos SET sueldo = :sueldo, idocupacion = :idocupacion, idusuario = :idusuario WHERE idsueldo = :idsueldo");

                $sql->execute(array(
                    ':sueldo' => $editarsueldo, ':idocupacion' => $editid_ocup, ':idusuario' => $editaridusuario, ':idsueldo' => $editidsueldo
                ));


                echo 'ok';
            }else{
                echo 'error2';
            }


           
            $sql->closeCursor();
            $sql=null;
            $db = null;

	}

	/*=============================================
	VERIFICAR DE PENSION X CODIGO
	=============================================*/
	public function verificarcodigopension($valor){
		$database = new Connection();
        $db = $database->open();

        $sql = $db->prepare("SELECT * FROM seguro_pension WHERE codigo = :codigo");
        $sql->execute(array(':codigo' => $valor));

        return $sql;


        $db= null;
        $sql=null;
	}


	/*=============================================
	GET PENSION POR IDPENSION
	=============================================*/
	public function getPension($valor){
		$database = new Connection();
        $db = $database->open();

        $sql = $db->prepare("SELECT * FROM seguro_pension WHERE idspension = :idspension");
        $sql->execute(array(':idspension' => $valor));

        return $sql->fetch();


        $db= null;
        $sql=null;
	}


    //consulta para obtener la busqueda por x rut buscado en el modal seguro salud
    public function Buscarempleado($criterio){
        $database = new Connection();
        $db = $database->open();

        $sql = $db->prepare("SELECT * FROM empleados WHERE rut LIKE '%$criterio%' ORDER BY nombres LIMIT 1 ");
        $sql->execute();

        return $sql;


        $sql->closeCursor();
        $db=null;
    }

    







	}

 ?>