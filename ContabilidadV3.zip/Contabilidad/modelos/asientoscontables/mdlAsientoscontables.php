<?php
	require_once '../../conexion/conexion.php';

class ModeloAsientos{

	/*=============================================
	MOSTRAR ASIENTOS CONTABLES
	=============================================*/

	static public function mdlMostrarAsientos(){

		try
        {

			$database = new Connection();
        	$db = $database->open();


			$stmt = $db->prepare("SELECT  *
				FROM plan_cuenta");

			
			$stmt->execute();

			return $stmt->fetchAll();

		

		$stmt -> close();

		$stmt = null;

		}catch(Exception $e)
        {
            die('Error Al Obtener AsientoModel -->'.$e->getMessage());
        }


	}


	/*=============================================
	INGRESAR PERIODO CONTABLE
	=============================================*/

	static public function mdlIngresarperido($fechainicial,$fechafinal,$codigo,$estado,$usuario,$fecha){

		try
        {

			$database = new Connection();
        	$db = $database->open();


			$stmt = $db->prepare("INSERT INTO periodo_contables (fecha_inicial, fecha_final, Codigo, estado, idusuario, fecharegistro)
				VALUES(:fecha_inicial, :fecha_final, :Codigo, :estado, :idusuario, :fecharegistro)");

			
			$stmt->execute(array(':fecha_inicial' => $fechainicial, ':fecha_final' => $fechafinal, ':Codigo' => $codigo, ':estado' => $estado, ':idusuario' => $usuario, ':fecharegistro' => $fecha));

			if ($stmt) {
				# code...
				echo 'ok';
			}else{
				echo 'error';
			}


		

		$stmt = null;
		$db=null;

		}catch(Exception $e)
        {
            die('Error Al Obtener Model Perido Asiento -->'.$e->getMessage());
        }


	}


	/*=============================================
	INGRESAR ASIENTOS CONTABLE
	=============================================*/

	public function mdlIngresarAsientoscontable($fecha,$idtipoperiodo,$idtipodiario,$idempresa,$estado,$concepto,$referencia,$codigocuenta,$nombrecuenta,$debe,$haber,$idusuario,$fechar){

		try
        {

			$database = new Connection();
        	$db = $database->open();


			$stmt = $db->prepare("INSERT INTO asientos_contables (referencia, concepto, fecha_contable, idtipodiario, idempresa, idestado, idusuario, fecharegistro)
				VALUES(:referencia, :concepto, :fecha_contable, :idtipodiario, :idempresa, :idestado, :idestado, :idusuario, :fecharegistro)");

			
			$stmt->execute(array(':referencia' => $referencia, ':concepto' => $concepto, ':fecha_contable' => $fecha, ':idtipodiario' => $idtipodiario, ':idempresa' => $idempresa, ':idestado' => $estado, ':idusuario' => $idusuario, ':fecharegistro' => $fechar));

			$idingresonew = $db->lastInsertId();

			    $num_elementos = 0;
                $sw = true;
                while ($num_elementos < count($codigocuenta)) {
                    //inserto los detalle compras proveedor
                    $sql_detalle = $db->prepare("INSERT INTO libromayor (idasientocontable, idtipolibro, codigocuenta, nombrecuenta, debe, haber, totaldebe, totalhaber) VALUES('$idingresonew','$idtipodiario[$num_elementos]','$codigocuenta[$num_elementos]','$nombrecuenta[$num_elementos]','$debe[$num_elementos]','$haber[$num_elementos]', '$totaldebe[$num_elementos]', '$totalhaber[$num_elementos]')");

                    $sql_detalle->execute() or $sw = false;


                    $sql_detalle = $db->prepare("INSERT INTO libro_diario (idasientocontable, idtipolibro, codigocuenta, nombrecuenta, debe, haber, totaldebe, totalhaber) VALUES('$idingresonew','$idtipodiario[$num_elementos]','$codigocuenta[$num_elementos]','$nombrecuenta[$num_elementos]','$debe[$num_elementos]','$haber[$num_elementos]', '$totaldebe[$num_elementos]', '$totalhaber[$num_elementos]')");

                    $sql_detalle->execute() or $sw = false;


                    
                    //incremento 1
                    $num_elementos = $num_elementos + 1;
                }

			if ($stmt) {
				# code...
				echo 'ok';
			}else{
				echo 'error';
			}


		

		$stmt = null;
		$db=null;

		}catch(Exception $e)
        {
            die('Error Al Obtener Model Asiento Contable -->'.$e->getMessage());
        }

	}


	/*=============================================
	VERIFICAR CODIGO ASIENTO CONTABLE
	=============================================*/
	public function	verificarCodigoasiento($ref){


		try {

			$database = new Connection();
        	$db = $database->open();

        	$stmt = $db->prepare("SELECT * FROM asientos_contables WHERE referencia = :referencia");
        	$stmt->execute(array(':referencia' => $ref));


        	return $stmt;



        	$stmt->closeCursor();
        	$stmt=null;
        	$db=null;
			
		} catch (Exception $e) {
			die('Error Al Obtener AsientoModel -->'.$e->getMessage());
		}









	}



	/*=============================================
	VERIFICAR CODIGO PERIODO CONTABLE
	=============================================*/
	public function verificarCodigo($codigo){
		try {

			$database = new Connection();
        	$db = $database->open();

        	$stmt = $db->prepare("SELECT * FROM periodo_contables WHERE Codigo = :Codigo");
        	$stmt->execute(array(':Codigo' => $codigo));


        	return $stmt;



        	$stmt->closeCursor();
        	$stmt=null;
        	$db=null;
			
		} catch (Exception $e) {
			die('Error Al Obtener AsientoModel -->'.$e->getMessage());
		}
	}


	/*=============================================
	BUSCAR CODIGO DE CATALOGO DE CUENTAS
	=============================================*/

	public function BuscarAsiento($criterio){

		try
          {

		$database = new Connection();
        $db = $database->open();



		$stm = $db->prepare("SELECT * FROM plan_cuenta WHERE n_digitos = :n_digitos");
        $stm->execute(array(':n_digitos' => $criterio));

        return $stm->fetch(PDO::FETCH_ASSOC);


        $stm -> close();

		$stm = null;


        }catch(Exception $e)
        {
            die('Error Al Obtener AsientoModel -->'.$e->getMessage());
        }

	}


	/*=============================================
	Listar periodo contable
	=============================================*/
	public function Verificarperiodo(){
		try
        {

			$database = new Connection();
        	$db = $database->open();


			$stmt = $db->prepare("SELECT  e.idestado, e.nombre, p.idperiodo, p.fecha_inicial, p.fecha_final, p.Codigo, p.estado, p.idusuario, p.fecharegistro, p.id_usuario, p.fechactualizado
				FROM periodo_contables p INNER JOIN estado e ON p.estado = e.idestado WHERE p.estado = 2");

			
			$stmt->execute();

			return $stmt;

		

		$stmt -> close();

		$stmt = null;

		}catch(Exception $e)
        {
            die('Error Al Obtener AsientoModel -->'.$e->getMessage());
        }
	}



	/*=============================================
	Listar estado
	=============================================*/
	public function Estado(){
		try
        {

			$database = new Connection();
        	$db = $database->open();


			$stmt = $db->prepare("SELECT  *
				FROM estado");

			
			$stmt->execute();

			return $stmt;

		

		$stmt -> close();

		$stmt = null;

		}catch(Exception $e)
        {
            die('Error Al Obtener AsientoModel -->'.$e->getMessage());
        }
	}


	/*=============================================
	Obtener datos por id de tabla periodo_contables
	=============================================*/

	public function getPeriodo($id){
		try
        {

			$database = new Connection();
        	$db = $database->open();


			$stmt = $db->prepare("SELECT  *
				FROM periodo_contables WHERE idperiodo = :idperiodo");

			
			$stmt->execute(array(':idperiodo' => $id));

			return $stmt->fetch(PDO::FETCH_OBJ);

		

		$stmt -> close();

		$stmt = null;

		}catch(Exception $e)
        {
            die('Error Al Obtener Periodo Model -->'.$e->getMessage());
        }
	}



	/*=============================================
	Actualizar datos por id de tabla periodo_contables
	=============================================*/
    public function mdlEditarPeriodo($fechainicial,$fechafinal,$codigo,$estado,$usuario,$fecha,$idperiodo){
    	try
        {

			$database = new Connection();
        	$db = $database->open();


        	$stmt=$db->prepare("SELECT * FROM periodo_contables WHERE Codigo = :Codigo");
        	$stmt->execute(array(':Codigo' => $codigo));

        	if ($stmt->rowCount() > 0) {
        		# code...
        		$sqlupdate = $db->prepare("UPDATE  periodo_contables  SET fecha_inicial = :fecha_inicial, fecha_final = :fecha_final, Codigo = :Codigo, estado = :estado, id_usuario = :id_usuario, fechactualizado = :fechactualizado WHERE idperiodo = :idperiodo");

			
				$sqlupdate->execute(array(':fecha_inicial' => $fechainicial, ':fecha_final' => $fechafinal, ':Codigo' => $codigo, ':estado' => $estado, ':id_usuario' => $usuario, ':fechactualizado' => $fecha, ':idperiodo' => $idperiodo));

				echo 'ok';
        	}else{
        		echo 'error2';
        	}


			

			


		
		$stmt->closeCursor();
		$sqlupdate=null;
		$stmt = null;
		$db=null;

		}catch(Exception $e)
        {
            die('Error Al Obtener Model Perido Asiento -->'.$e->getMessage());
        }
    }


	   /*=============================================
	  LISTADO DE TIPOS DIARIOS
	  =============================================*/
	  public function Listarperiodo(){

	    
	        $database = new Connection();
	        $db = $database->open();

	        $stmt=$db->prepare("SELECT * FROM periodo_contables WHERE estado = 2 LIMIT 1 ");
	        $stmt->execute();

	        return $stmt;



	        $db->close();
	        $stmt=null;
	  }






}