<?php 

  require_once '../../conexion/conexion.php';
  class ModelDiarios{

  /*=============================================
  LISTADO DE TIPOS DIARIOS
  =============================================*/
  public function tipoDiarios(){

    
        $database = new Connection();
        $db = $database->open();

        $stmt=$db->prepare("SELECT * FROM tipo_diarios ");
        $stmt->execute(array(':idusuario' => $usuario));

        return $stmt -> fetchAll();



        $db->close();
        $stmt=null;
  }

  

  /*=============================================
  VERIFICAR CODIGO EN TIPO_DIARIOS
  =============================================*/
  public function verificarCodigo($codigo){
    try
    {

        $database = new Connection();
        $db = $database->open();

        $sql = $db->prepare("SELECT * FROM tipo_diarios WHERE codigo = :codigo");
        $sql->execute(array(':codigo' => $codigo));



        return $sql;


        $db->close();
        $sql=null;

        $db= null;


      

    }catch(PDOException $ex){
      echo 'Error al modelo Diarios --> '.$ex->getMessage();
    }
  }




 /*=============================================
 REGISTRO  DE TIPOS DIARIOS
  =============================================*/

  public function mdlIngresarDiario($codigo, $nombre, $idusuario, $fecha){
     try
       {

        $database = new Connection();
        $db = $database->open();

        $sql = $db->prepare("INSERT INTO tipo_diarios (codigo, nombre, id_usuario, fecharegistro) VALUES(:codigo, :nombre, :id_usuario, :fecharegistro)");
        $sql->execute(array(':codigo' => $codigo, ':nombre' => $nombre, ':id_usuario' => $idusuario, ':fecharegistro' => $fecha));


        if ($sql) {
          # code...
          echo 'ok';
        }else{
          echo 'error';
        }


       
        $sql=null;

        $db= null;


      

      }catch(PDOException $ex){
       echo 'Error al modelo Diarios --> '.$ex->getMessage();
      }
  }

  /*=============================================
  EDITAR Diario
  =============================================*/
  public function mdlEdiatrDiario($codigo, $nombre, $idusuario, $fecha, $idtipod){
     try
       {

        $database = new Connection();
        $db = $database->open();

        $sql = $db->prepare("SELECT * FROM tipo_diarios WHERE codigo = :codigo");
        $sql->execute(array(':codigo' => $codigo));

        if ($sql->rowCount() == 0) {
          # code...
          $sqlupdate = $db->prepare("UPDATE  tipo_diarios SET codigo = :codigo, nombre = :nombre, idusuario = :idusuario, fechactualizado= :fechactualizado WHERE idtipod = :idtipod");
          $sqlupdate->execute(array(':codigo' => $codigo, ':nombre' => $nombre, ':idusuario' => $idusuario, ':fechactualizado' => $fecha, ':idtipod' => $idtipod));

          echo 'ok';

        }else{
          echo 'error2';
        }


      
        $sql->closeCursor(); 
        $sql=null;
        $sqlupdate=null;

        $db= null;


      

      }catch(PDOException $ex){
       echo 'Error al modelo Diarios --> '.$ex->getMessage();
      }
  }


  /*=============================================
  GET SUELDO POR IDSUELDO
  =============================================*/
  public function getDiario($valor){
    try
       {


        $database = new Connection();
        $db = $database->open();

        $sql = $db->prepare("SELECT * FROM tipo_diarios WHERE idtipod = :idtipod");
        $sql->execute(array(':idtipod' => $valor));

        return $sql->fetch();


        $db= null;
        $sql=null;

        }catch(PDOException $ex){
          echo 'Error al modelo Diarios --> '.$ex->getMessage();
        }
  }











  }













 ?>