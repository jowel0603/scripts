<?php 

	require_once '../../conexion/conexion.php';
	class ModeloMunicipio
	{


	/*=============================================
	LISTADO DE MUNICIPIOS
	=============================================*/
	public function Municipio(){
		$database = new Connection();
        $db = $database->open();

        $stmt=$db->prepare("SELECT * FROM munpio");
        $stmt->execute();

        return $stmt -> fetchAll();



        $db->close();
        $stmt=null;
	}



	/*=============================================
	OBTENER UN CODIGO  DE MUNICIPIOS
	=============================================*/
	public function getMunicipio($cod){
		$database = new Connection();
        $db = $database->open();

        $stmt=$db->prepare("SELECT * FROM munpio WHERE cod_dpto = :cod_dpto");
        $stmt->execute(array(':cod_dpto' => $cod ));

        return $stmt;



        $db->close();
        $stmt=null;
	}








	}

 ?>