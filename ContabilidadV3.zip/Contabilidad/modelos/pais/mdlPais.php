<?php 

	require_once '../../conexion/conexion.php';
	class ModeloPais
	{


	/*=============================================
	LISTADO DE PAIS
	=============================================*/
	public function Pais(){
		$database = new Connection();
        $db = $database->open();

        $stmt=$db->prepare("SELECT * FROM pais");
        $stmt->execute();

        return $stmt -> fetchAll();



        $db->close();
        $stmt=null;
	}








	}

 ?>