<?php 

	require_once '../../conexion/conexion.php';
	class ModeloSeguro
	{


	/*=============================================
	LISTADO DE SEGURO
	=============================================*/
	public function Seguro($usuario){
		$database = new Connection();
        $db = $database->open();

        $stmt=$db->prepare("SELECT s.idsegurosalud, s.codigo, s.nombre, s.valor, s.idempleado, s.idusuario, e.idempleado, e.nombres
        	FROM seguero_salud s 
            INNER JOIN empleados e 
            ON s.idempleado = e.idempleado WHERE s.idusuario = :idusuario");
        $stmt->execute(array(':idusuario' => $usuario));

        return $stmt -> fetchAll();



        $db->close();
        $stmt=null;
	}


	/*=============================================
	REGISTRO DE SEGURO
	=============================================*/
	public function mdlIngresarsegurosalud($codigo, $nombre,$valor,$idempleado,$usuario, $fecha){
		$database = new Connection();
        $db = $database->open();

        $sql = $db->prepare("INSERT INTO  seguero_salud (codigo, nombre, valor, idempleado, idusuario, fecharegistro) VALUES(:codigo, :nombre, :valor, :idempleado, :idusuario, :fecharegistro)");
        $sql->execute(array(':codigo' => $codigo, ':nombre' => $nombre, ':valor' => $valor, ':idempleado' =>$idempleado, ':idusuario' => $usuario, ':fecharegistro' => $fecha));

        if ($sql) {
        	# code...
        	return 'ok';
        }else{
        	return 'error';
        }


        $db=null;
        $sql=null;

	}


	/*=============================================
	EDITAR  SEGURO 
	=============================================*/
	public function mdlEditarsueldo($editarsueldo,$editid_ocup,$editaridusuario,$editidsueldo){

		$database = new Connection();
        $db = $database->open();

            $sql=$db->prepare("SELECT s.idocupacion, o.id_ocup FROM sueldos s INNER JOIN ocupaciones o ON s.idocupacion = o.id_ocup WHERE idocupacion = :idocupacion  ");
            $sql->execute(array(':idocupacion' => $editid_ocup));

            if($sql->rowCount() > 0){

                $sql = $db->prepare("UPDATE sueldos SET sueldo = :sueldo, idocupacion = :idocupacion, idusuario = :idusuario WHERE idsueldo = :idsueldo");

                $sql->execute(array(
                    ':sueldo' => $editarsueldo, ':idocupacion' => $editid_ocup, ':idusuario' => $editaridusuario, ':idsueldo' => $editidsueldo
                ));


                echo 'ok';
            }else{
                echo 'error2';
            }


           
            $sql->closeCursor();
            $sql=null;
            $db = null;

	}

	/*=============================================
	VERIFICAR DE SEGURO X CODIGO
	=============================================*/
	public function verificarcodigoseguro($valor){
		$database = new Connection();
        $db = $database->open();

        $sql = $db->prepare("SELECT * FROM seguero_salud WHERE codigo = :codigo");
        $sql->execute(array(':codigo' => $valor));

        return $sql;


        $db= null;
        $sql=null;
	}


	/*=============================================
	GET SUELDO POR IDSEGURO
	=============================================*/
	public function getSeguro($valor){
		$database = new Connection();
        $db = $database->open();

        $sql = $db->prepare("SELECT * FROM seguero_salud WHERE idseguro = :idseguro");
        $sql->execute(array(':idseguro' => $valor));

        return $sql->fetch();


        $db= null;
        $sql=null;
	}

    







	}

 ?>