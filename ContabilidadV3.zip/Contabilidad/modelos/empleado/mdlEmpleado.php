<?php 

	require_once '../../conexion/conexion.php';
	class ModeloEmpleado
	{

			/*=============================================
			LISTADO DE EMPLEADO
			=============================================*/
			public function Empleado($usuario){
				$database = new Connection();
		        $db = $database->open();

		        $stmt=$db->prepare("SELECT e.idusuario, e.idempleado, e.nombres, e.apellidos, e.rut, e.celular, e.telefono, e.direccion, e.genero, e.idempresa, e.idciudad, e.idsucursal, e.idusuario, em.idempresa, em.nombre
		        	FROM empleados e 
		        	INNER JOIN empresa em ON e.idempresa = em.idempresa WHERE e.idusuario = :idusuario   ");
		        $stmt->execute(array(':idusuario' => $usuario));

		        return $stmt -> fetchAll();



		        $db=null;
		        $stmt=null;
			}






			/*=============================================
			REGISTRO DE EMPLEADO
			=============================================*/

			static public function mdlIngresarEmpleado($nombre,$apellidos,$rut,$direccion,$telefono,$celular,$cod_dpto,$cod_mun,$empresa,$usuario,$fecha,$genero){

				$database = new Connection();
		        $db = $database->open();

		      
			        $stmt = $db->prepare("INSERT INTO empleados (nombres, apellidos, rut, celular, telefono, direccion, genero, idempresa, idciudad, idsucursal, idusuario, fecharegistro) VALUES (:nombres, :apellidos, :rut, :celular, :telefono, :direccion, :genero, :idempresa, :idciudad, :idsucursal, :idusuario, :fecharegistro)");
			        $stmt->execute(array(':nombres' => $nombre, ':apellidos' => $apellidos, ':rut' => $rut, ':celular' => $celular, ':telefono' => $telefono,  ':direccion' => $direccion, ':genero' => $genero, ':idempresa' => $empresa, ':idciudad' => $cod_dpto, ':idsucursal' => $cod_mun, ':idusuario' => $usuario, ':fecharegistro' => $fecha));
			        


					if($stmt){

						return "ok";	

					}else{

						return "error";
					
					}
		        

				

				
				
				$stmt = null;
				$db->close();

			}

			/*=============================================
			ACTUALIZAR DE EMPLEADO
			=============================================*/
			public function mdlEditarempleado($nombre,$ruc,$direccion,$telefono,$celular,$email,$usuario,$idempresa){

				$database = new Connection();
		        $db = $database->open();

		            $sql=$db->prepare("SELECT * FROM empleados WHERE correo = :correo and  nit = :nit  ");
		            $sql->execute(array(':correo' => $email, ':nit' => $ruc));

		            if($sql->rowCount() > 0){

		                $sql = $db->prepare("UPDATE empleados SET nombre = :nombre, nit = :nit, direccion = :direccion, telefono = :telefono, celular = :celular, correo = :correo, idusuario = :idusuario WHERE idempresa = :idempresa");

		                $sql->execute(array(
		                    ':nombre' => $nombre, ':nit' => $ruc, ':direccion' => $direccion, ':telefono' => $telefono,
		                    ':celular' => $celular, ':correo' => $email, ':idusuario' => $usuario, ':idempresa' => $idempresa
		                ));


		                echo 'ok';
		            }else{
		                echo 'error2';
		            }


		           
		            $sql->closeCursor();
		            $sql=null;
		            $db = null;
			}

			/*=============================================
			OBTENER DATOS DE EMPLEADO
			=============================================*/
			public function getEmpresa($id){

				$database = new Connection();
		        $db = $database->open();


				$sql = $db->prepare("SELECT * FROM empleados WHERE idempresa = :idempresa ");
				$sql->execute(array(':idempresa' => $id));


				return $sql->fetch();


				$sql->closeCursor();
		        $db->close();

			}


			/*=============================================
			CONSULTO QUE SI EXISTE O NO EL NIT  DE EMLEADO
			=============================================*/
			public function verificarnitempresa($valor){


				$database = new Connection();
		        $db = $database->open();

		        $sql = $db->prepare("SELECT * FROM empleados WHERE nit = :nit");
		        $sql->execute(array(':nit' => $valor));

		        return $sql;


		        $sql->closeCursor();
		        $db->close();
			}


			/*=============================================
			CONSULTO QUE SI EXISTE O NO EL RUT  DE EMPLEADO
			=============================================*/
			public function verificarnitempleado($valor){

				$database = new Connection();
		        $db = $database->open();

		        $sql = $db->prepare("SELECT * FROM empleados WHERE rut = :rut");
		        $sql->execute(array(':rut' => $valor));

		        return $sql;


		        $sql->closeCursor();
		        $db->close();
			}


			//consulta para obtener la busqueda por x rut buscado en el modal seguro salud
			public function Buscarempleado($criterio){
				$database = new Connection();
		        $db = $database->open();

		        $sql = $db->prepare("SELECT * FROM empleados WHERE rut LIKE '%$criterio%' ORDER BY nombres LIMIT 1 ");
		        $sql->execute();

		        return $sql;


		        $sql->closeCursor();
		        $db=null;
			}

			//consulta para obtener la busqueda por x rut buscado en el modal seguro salud
			public function Buscar_Rut_empleado_Asignacion_Sueldo($criterio)
			{
				try 
				{
					$database = new Connection();
			        $db = $database->open();

			        $sql = $db->prepare("SELECT * FROM empleados WHERE rut LIKE '%$criterio%' ORDER BY nombres LIMIT 1 ");
			        $sql->execute();

			        return $sql;


			        $sql->closeCursor();
			        $db=null;





				} 
				catch (Exception $e) 
				{
					echo "Error mdlEmpleado--->'Buscar_Rut_empleado_Asignacion_Sueldo' ".$e->getMessage();
				}
				catch (PDOException $ex)
				{
					echo "Error mdlEmpleado--->'Buscar_Rut_empleado_Asignacion_Sueldo'  Modelo ------> ".$ex->getMessage();
				}


			}











	}//cierre de la clase 













 ?>