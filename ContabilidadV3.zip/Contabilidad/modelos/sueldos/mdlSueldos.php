<?php 

	require_once '../../conexion/conexion.php';
	class ModeloSueldos
	{


	/*=============================================
	LISTADO DE SUELDOS
	=============================================*/
	public function Sueldos($usuario)
    {
		try
        {
                $database = new Connection();
                $db = $database->open();

                $stmt=$db->prepare("SELECT s.idsueldo, s.sueldo, s.idocupacion, s.idusuario, o.id_ocup, o.ocupacion 
                    FROM sueldos s INNER JOIN ocupaciones o ON s.idocupacion = o.id_ocup WHERE s.idusuario = :idusuario");
                $stmt->execute(array(':idusuario' => $usuario));

                return $stmt -> fetchAll();



                $db->close();
                $stmt=null;
        }
        catch (Exception $e) 
        {
            echo "Error Al Obtener mdlSueldos --> Sueldos  ".$e->getMessage();
        }
        catch (PDOException $ex)
        {
             echo "Error Al Obtener mdlSueldos --> Sueldos ".$ex->getMessage();

        }
	}





    public function registroSueldo($id_empleado, $rut, $sueldo, $idocupacion, $idusuario, $fecharegistro){
        try
        {
            $database = new Connection();
            $db = $database->open();

            $mipush=false;
            $stmt = $db->prepare(" 
            
            INSERT INTO sueldos (id_empleado, rut,  sueldo, idocupacion, idusuario, fecharegistro) 

            VALUES ('".$id_empleado."','".$rut."','".$sueldo."','".$idocupacion."','".$idusuario."','".$fecharegistro."') 

            ");
            $stmt->execute();//ejecuta la consulta ahora funciona el registrar

            $mipush=$stmt->fetch(PDO::FETCH_ASSOC);

            if($mipush)
            {
                echo "Registro Exitoso :) ";
                # code...
                echo 'ok';
                return true;  
            }
            else
            {
                echo "Error Al Insertar Sueldo empleado =( ";
                echo "error";
                return false;
            }

            
            

            $db=null;
            $stmt=null;

        }   
        catch (Exception $e) 
        {
        //mira lo que hiciste o que pq es como si validaara para obtener el modelo .... pq esta bien el imnirsearata  esto 
            echo "Error Al Obtener mdlSueldos  ".$e->getMessage();
        }
        catch (PDOException $ex)
        {
             echo "Error Al Obtener mdlSueldos consulta ".$ex->getMessage();

        }
    }


	/*=============================================
	EDITAR  SUELDOS 
	=============================================*/
	public function mdlEditarsueldo($editarsueldo,$editid_ocup,$editaridusuario,$editidsueldo)
    {

		$database = new Connection();
        $db = $database->open();

            $sql=$db->prepare("SELECT s.idocupacion, o.id_ocup FROM sueldos s INNER JOIN ocupaciones o ON s.idocupacion = o.id_ocup WHERE idocupacion = :idocupacion  ");
            $sql->execute(array(':idocupacion' => $editid_ocup));

            if($sql->rowCount() > 0){

                $sql = $db->prepare("UPDATE sueldos SET sueldo = :sueldo, idocupacion = :idocupacion, idusuario = :idusuario WHERE idsueldo = :idsueldo");

                $sql->execute(array(
                    ':sueldo' => $editarsueldo, ':idocupacion' => $editid_ocup, ':idusuario' => $editaridusuario, ':idsueldo' => $editidsueldo
                ));


                echo 'ok';
            }else{
                echo 'error2';
            }


           
            $sql->closeCursor();
            $sql=null;
            $db = null;

	}

	/*=============================================
	VERIFICAR DE SUELDOS X IDOCUPACION
	=============================================*/
	public function verificarsueldo($valor){
		$database = new Connection();
        $db = $database->open();

        $sql = $db->prepare("SELECT * FROM sueldos WHERE idocupacion = :idocupacion");
        $sql->execute(array(':idocupacion' => $valor));

        return $sql;


        $db= null;
        $sql=null;
	}


	/*=============================================
	GET SUELDO POR IDSUELDO
	=============================================*/
	public function getSueldo($valor){
		$database = new Connection();
        $db = $database->open();

        $sql = $db->prepare("SELECT * FROM sueldos WHERE idsueldo = :idsueldo");
        $sql->execute(array(':idsueldo' => $valor));

        return $sql->fetch();


        $db= null;
        $sql=null;
	}








	}



 ?>