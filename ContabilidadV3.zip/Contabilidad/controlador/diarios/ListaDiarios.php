<?php
session_start();
$action = (isset($_REQUEST['action'])&& $_REQUEST['action'] !=NULL)?$_REQUEST['action']:'';
if($action == 'ajax'){
	$query = htmlspecialchars(((strip_tags($_REQUEST['query'], ENT_QUOTES))));

		require_once '../../conexion/conexion.php';
 
	/*------------------------------------------*/
	    $database=new Connection();
	    /*------------------------------------------*/
	    $db=$database->open();
		


		$tables="tipo_diarios";
		$campos="*";
		$sWhere=" tipo_diarios.codigo LIKE '%".$query."%' or tipo_diarios.nombre LIKE '%".$query."%'  ";
		$sWhere.=" order by tipo_diarios.codigo";

		
		
		
		include '../../funciones/pagination.php'; //include pagination file
		//pagination variables
		$page = (isset($_REQUEST['page']) && !empty($_REQUEST['page']))?$_REQUEST['page']:1;
		$per_page = intval($_REQUEST['per_page']); //how much records you want to show
		$adjacents  = 4; //gap between pages after number of adjacents
		$offset = ($page - 1) * $per_page;
		//Count the total number of row in your table*/
		$count_query   = $db->prepare("SELECT count(*) AS numrows FROM $tables where $sWhere ");
		$count_query->execute();

		$numrows=0; 
		
		if ($row=$count_query->fetch(PDO::FETCH_ASSOC)){
			$numrows = $row['numrows'];
		}
		else {
			echo mysqli_error($db, $count_query);
		}
		$total_pages = ceil($numrows/$per_page);
		//main query to fetch the data
		$query = $db->prepare("
			SELECT *
			FROM  tipo_diarios 
			 
			  where codigo LIKE '%".$query."%' or nombre LIKE '%".$query."%'  LIMIT $offset,$per_page");
		$query->execute();
		//loop through fetched data
		
		
 
 
		
	
	if ($numrows>0){
		
	?>
		<div class="table-responsive">
			<table class="table table-striped table-hover tablas">
				<thead>
					<tr>
						<th>Codigo</th>
                        <th>Nombre</th>
                        <th>Opciones</th>
					</tr>
				</thead>
				<tbody>	
						<?php 
						$finales=0;
						while($row =$query->fetch(PDO::FETCH_ASSOC)){	
							$idtipod = $row["idtipod"];
							$codigo=$row['codigo'];
							$nombre=$row['nombre'];			
							$finales++;
						?>	
						<tr class="">
							<td class='text-center'><?php echo $codigo;?></td>
							<td ><?php echo $nombre;?></td>
							<td>
								
								<button class="btn btn-success btn-xs edit btn-flat" data-id="<?php echo $row['idtipod']; ?>"><i class="fa fa-edit"></i> Editar</button>
                            		
						           
						           
						           
                    		</td>
						</tr>
						<?php }?>
						<tr>
							<td colspan='8'> 
								<?php 
									$inicios=$offset+1;
									$finales+=$inicios -1;
									echo "Mostrando $inicios al $finales de $numrows registros";
									echo paginate( $page, $total_pages, $adjacents);
								?>
							</td>
						</tr>
				</tbody>			
			</table>
		</div>	


		<!-- MODAL EDITAR  -->
		<!-- The Modal -->
		<div class="modal" id="edit">
		  <div class="modal-dialog">
		    <div class="modal-content">

		      <!-- Modal Header -->
		      <div class="modal-header">
		        <h4 class="modal-title">Formulario Editar Diario</h4>
		        <button type="button" class="close" data-dismiss="modal">&times;</button>
		        
		      </div>
		      <div id="msg-info">
		          
		      </div>

		      <!-- Modal body -->
		      <div class="modal-body">
		        <form id="editDiario" name="editDiario" class="form-horizontal"  >
		          <input type="hidden" class="form-control" id="editaridusuario" name="editaridusuario" value="<?php echo $_SESSION["id"];  ?>" >
		          <input type="hidden" class="form-control" id="editidtipod" name="editidtipod" value="" >


		                <div class="form-group">
		                    <label for="codigo" class="col-sm-3 control-label">Codigo</label>

		                <div class="col-md-12">
		                  <input type="text" class="form-control" id="editcodigo" name="editcodigo" autocomplete="off"  >
		                </div>
		                </div>
		                <div class="form-group">
		                    <label for="nombre" class="col-sm-3 control-label">Nombre</label>
		                      <input type="text" id="editnombre" name="editnombre" class="form-control" autocomplete="off" >
		                </div>
		                
		                
		                
		            </div>
		            <div class="modal-footer">
		              <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
		              <button type="submit" class="btn btn-primary btn-flat editarDiario"><i class="fa fa-check-square-o"></i>Actualizar</button>
		              
		     	 	</div>

		      </form>

		      

		    </div>
		  </div>
		</div>



	
	<?php	
	}	else{
			//aqui muestro que no hay datos cuando esta buscando un usuario
			echo '<table class="table table-striped table-hover tablas">
					<thead>
						<tr>
	                    <th>Codigo</th>
                        <th>Nombre</th>
                        <th>Opciones</th>
	                 </tr>
	                </thead>

	                <tbody>

	                <td>

	                <div  style="width: 200px; text-align: center;">
     						No hay datos
					</div>

					</td>
					</tbody>

					<tfooter>
					<tr>
	                    <th>Codigo</th>
                        <th>Nombre</th>
                        <th>Opciones</th>
	                 </tr>
	                 </tfooter>

				</table>';
	}
}
?>   

<script type="text/javascript">
	$(function(){


		//accion al darle click editar al diario y muestra el modal
		$('.edit').click(function(e){
    		e.preventDefault();
		    $('#edit').modal('show');
		    var id = $(this).data('id');

		    //funcion get diario
		    getRow(id);
  		});


		$('.editarDiario').on('click',function(evnt){
			evnt.preventDefault();

			let Formdata = $('#editDiario').serialize();


			$.ajax({
				url: '../../controlador/diarios/editarDiarios.php',
				type: 'POST',
				data: Formdata,
				dataType: 'html',
				async: true,
				cache:false,

				beforeSend: function(ob){
					$('#msg-info').html('<div class="alert alert-info alert-dismissible fade show" role="alert">'+
  											'<strong>Información!  </strong>Actualizando datos, porfavor espere un momento.'+
				  							'<button type="button" class="close" data-dismiss="alert" aria-label="Close">'+
				    							'<span aria-hidden="true">&times;</span>'+
				  							'</button>'+
											'</div>');
				} ,
				success: function(respuesta){
					if (respuesta == 'ok') {
						$('#msg-info').html('<div class="alert alert-success alert-dismissible fade show" role="alert">'+
  											'<strong>Exito!</strong> Actualizado Diario correctamente.'+
				  							'<button type="button" class="close" data-dismiss="alert" aria-label="Close">'+
				    							'<span aria-hidden="true">&times;</span>'+
				  							'</button>'+
											'</div>');

						
						setTimeout(function(){location.reload();},2000);
					}else if (respuesta == 'error') {
						$('#msg-info').html('<div class="alert alert-danger alert-dismissible fade show" role="alert">'+
  											'<strong>ERROR!</strong> Error al actualizar los datos.'+
				  							'<button type="button" class="close" data-dismiss="alert" aria-label="Close">'+
				    							'<span aria-hidden="true">&times;</span>'+
				  							'</button>'+
											'</div>');
					}else if(respuesta == 'error2'){
							$('#msg-info').html('<div class="alert alert-danger alert-dismissible fade show" role="alert">'+
  											'<strong>ERROR!</strong>Ya hay un Registro de Diario con este Codigo.'+
				  							'<button type="button" class="close" data-dismiss="alert" aria-label="Close">'+
				    							'<span aria-hidden="true">&times;</span>'+
				  							'</button>'+
											'</div>');
					}else if(respuesta == '9'){
							$('#msg-info').html('<div class="alert alert-danger alert-dismissible fade show" role="alert">'+
  											'<strong>ERROR!</strong> Todos los campos son obligatorios.'+
				  							'<button type="button" class="close" data-dismiss="alert" aria-label="Close">'+
				    							'<span aria-hidden="true">&times;</span>'+
				  							'</button>'+
											'</div>');
					}else if(respuesta == "8"){
							$('#msg-info').html('<div class="alert alert-danger alert-dismissible fade show" role="alert">'+
  											'<strong>ERROR!</strong> Caracteres mayor de 10 .'+
				  							'<button type="button" class="close" data-dismiss="alert" aria-label="Close">'+
				    							'<span aria-hidden="true">&times;</span>'+
				  							'</button>'+
											'</div>');
					}

					
				}
			});
		});





	});
		//trae datos de diarios por id
	  function getRow(id){
	  $.ajax({
	    type: 'POST',
	    url: '../../controlador/diarios/getDiario.php',
	    data: {id:id},
	    dataType: 'json',
	    success: function(response){
	    	$('#editidtipod').val(response.idtipod);
	    	$('#editcodigo').val(response.codigo);
			$('#editnombre').val(response.nombre);
			$('#editaridusuario').val(response.id_usuario);
	      
	    }
	  });
}
</script>  
