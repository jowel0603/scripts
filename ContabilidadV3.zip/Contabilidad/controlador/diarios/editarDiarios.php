<?php 
	sleep(1);
if ($_SERVER['REQUEST_METHOD'] == 'POST') {



	if(!empty($_POST["editcodigo"]) && !empty($_POST["editnombre"]) && !empty($_POST["editidtipod"]) && !empty($_POST["editaridusuario"])   ){

		if (strlen($_POST["editnombre"]) > 15) {

			

				require_once '../../funciones/funciones.php';
  				

			    	$nombre=htmlspecialchars(addslashes($_POST["editnombre"]));
				    $codigo=htmlspecialchars(addslashes($_POST["editcodigo"]));
				    $idusuario=intval($_POST["editaridusuario"]);
				    $iddiario=intval($_POST["editidtipod"]);
				    $fecha = gmdate('Y-m-d H:i:s', hora_local(-5));

				    	require_once "../../modelos/Diarios/mdlDiarios.php";

				    	$mdlDiario = new ModelDiarios();


				    	

			            	 $registroDiario = $mdlDiario::mdlEdiatrDiario($codigo, $nombre, $idusuario, $fecha, $iddiario);

						    if($registroDiario == 'ok'){
						    	echo $registroDiario;
						    }else if($registroDiario == 'error'){
						    	echo $registroDiario;
						    }else if ($registroDiario == 'error2') {
						    	# code...
						    	echo $registroDiario;
						    }
			            


				    
			    	
			    }else{
			    	echo 8;
			    }

		}else{
			echo 9;
		}

		
	}else{
		echo 'Error Inesperado';
	}





 ?>