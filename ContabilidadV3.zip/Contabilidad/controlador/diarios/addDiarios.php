<?php 
	sleep(1);
if ($_SERVER['REQUEST_METHOD'] == 'POST') {



	if(!empty($_POST["codigo"]) && !empty($_POST["nombre"]) && !empty($_POST["idusuario"])   ){

		if (strlen($_POST["nombre"]) > 15) {

			

				require_once '../../funciones/funciones.php';
  				

			    	$nombre=htmlspecialchars(addslashes($_POST["nombre"]));
				    $codigo=htmlspecialchars(addslashes($_POST["codigo"]));
				    $idusuario=$_POST["idusuario"];
				    $fecha = gmdate('Y-m-d H:i:s', hora_local(-5));

				    	require_once "../../modelos/Diarios/mdlDiarios.php";

				    	$mdlDiario = new ModelDiarios();


				    	$verificar = $mdlDiario->verificarCodigo($codigo);

				    	if ($verificar->rowCount() > 0) {
			                # code...
			               	echo 'error2';
			               	return false;
			                
			                
			            }else{

			            	 $registroDiario = $mdlDiario::mdlIngresarDiario($codigo, $nombre, $idusuario, $fecha);

						    if($registroDiario == 'ok'){
						    	echo $registroDiario;
						    }else if($registroDiario == 'error'){
						    	echo $registroDiario;
						    }
			            }


				    
			    	
			    }else{
			    	echo 8;
			    }

		}else{
			echo 9;
		}

		
	}else{
		echo 'Error Inesperado';
	}





 ?>