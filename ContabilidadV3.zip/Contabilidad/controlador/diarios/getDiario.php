<?php 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	if (!empty($_POST["id"])) {
		# code...
		$id = htmlspecialchars($_POST["id"]);


		require_once '../../modelos/Diarios/mdlDiarios.php';

		$mdlDiario = new ModelDiarios();

		$obtener = $mdlDiario->getDiario($id);


		echo json_encode($obtener);
	}

	
		

}else{
	echo 9;
}



 ?>