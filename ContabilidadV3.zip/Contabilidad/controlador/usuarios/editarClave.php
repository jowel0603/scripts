<?php 
	

	sleep(2);

	if ($_SERVER["REQUEST_METHOD"] == 'POST') {

		if (!empty($_POST["editclave"]) && !empty($_POST["clave2"]) && !empty($_POST["claveconfirmar"])) {
			# code...
			require_once '../../funciones/funciones.php';



				if (validar_clave($_POST["clave2"]) ){

					if (validar_clave($_POST["claveconfirmar"])) {
						# code...
						
						$idusuario = intval($_POST["idusu"]);
						$claveactual = sha1($_POST["editclave"]);

						$claveactual2 = sha1($_POST["clave2"]);


						$claveactual3 = sha1($_POST["claveconfirmar"]);


						//incluyo modelo
						require_once '../../modelos/Usuarios/mdlUsuarios.php';
									

						//instancio el modelo
						$usuarios = new ModeloUsuarios();


						$validarnumero=$usuarios->getClave($claveactual,$idusuario);

						
						if($num = $validarnumero->rowCount() == 1){

							if ($_POST["clave2"] != $_POST["claveconfirmar"]) {
								# code...
								echo 6;
								
							}else{
								
								$updateClave = $usuarios->updateClave($idusuario,$claveactual2);

								if ($updateClave  == 1) {
									# code...
									echo $updateClave ;
								}else if($updateClave  == 2){
									echo $updateClave ;
								}
							}



						}else{
							echo 7;
						}


					}else{
						echo 8;
					}



				}else{
					echo 8;
				}




			
		}else{
			echo 9;
		}




	}else{
		echo 0;
	}



 ?>