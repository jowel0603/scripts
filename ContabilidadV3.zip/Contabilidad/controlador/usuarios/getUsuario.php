<?php 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	if (!empty($_POST["id"])) {
		# code...
		

		$id = strip_tags(htmlentities($_POST["id"]));
		require_once '../../modelos/Usuarios/mdlUsuarios.php';

		//instancio el modelo
		$usuarios = new ModeloUsuarios();



		$obtener = $usuarios->getUsuarioId($id);
		$datos=$obtener->fetch(PDO::FETCH_ASSOC);


		


		echo json_encode($datos);


		

		
	}else{
		echo 9;
	}

	
		

}else{
	echo 9;
}



 ?>