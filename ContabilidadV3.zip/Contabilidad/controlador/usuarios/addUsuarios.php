<?php 
	sleep(2);

	if ($_SERVER["REQUEST_METHOD"] == 'POST') {
		
		# code...
		
		if (!empty($_POST["nombre"])  && !empty($_POST["idusuario"]) && !empty($_POST["tipo_documento"]) && !empty($_POST["direccion"]) && !empty($_POST["num_documento"]) && !empty($_POST["telefono"]) && !empty($_POST["celular"]) && !empty($_POST["email"]) && !empty($_POST["cargo"]) && !empty($_POST["usuario"])  &&  !empty($_POST["clave"]) && !empty($_POST["permiso"])  ) {
			# code...
			
			if (preg_match('/^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ ]+$/', $_POST["nombre"])) {
				# code...
				if (filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)) {
					# code...
					if (strlen($_POST["num_documento"]) >= 13 || strlen($_POST["num_documento"]) >= 10) {
						# code...
						if (preg_match('/^[#\.\-a-zA-Z0-9 ]+$/', $_POST["direccion"])) {
							# code...
							# 
							require_once '../../funciones/funciones.php';



							if (validar_clave($_POST["clave"])){
      							
							



							$nombre= strip_tags(htmlentities($_POST["nombre"]));
							$tipo_documento = strip_tags(htmlentities($_POST["tipo_documento"]));
							$direccion = strip_tags(htmlentities(trim($_POST["direccion"])));
							$num_documento = htmlspecialchars(((strip_tags($_POST['num_documento'], ENT_QUOTES))));
							$telefono = intval($_POST["telefono"]);
							$celular = intval($_POST["celular"]);
							$email = trim($_POST["email"]);
							$cargo = htmlspecialchars(strip_tags($_POST["cargo"]));
							$usuario = htmlspecialchars(strip_tags($_POST["usuario"]));
							$clave = sha1($_POST["clave"]);
							$permiso = intval($_POST["permiso"]);
							$estado = intval($_POST["estado"]);
							$idusuario = intval($_POST["idusuario"]);				
							$fecha = gmdate('Y-m-d H:i:s', hora_local(-5));

							
							//incluyo modelo
							require_once '../../modelos/Usuarios/mdlUsuarios.php';
							

							//instancio el modelo
							$usuarios = new ModeloUsuarios();
							$validarnumero=$usuarios->getNumero($num_documento);
							$validaremail = $usuarios->getEmail($email);
							$validarusuario = $usuarios->getUsuario($usuario);

							if ($validarnumero->rowCount() > 0) {
								# code...
								echo 4;
								return false;

							}else if($validaremail->rowCount() > 0){
								echo 3;
								return false;
							}else if($validarusuario->rowCount() > 0){
								echo 2;

								return false;
							}else{
								$respuesta = $usuarios->addUsuarios($nombre,$tipo_documento,$num_documento,$celular,$telefono,$email,$direccion,$usuario,$clave,$cargo,$estado,$idusuario,$fecha,$_POST["permiso"]);
 
								if($respuesta){
									echo '<div class="alert alert-info " data-dismiss="alert" role="alert"> Se Ingreso Correctamente! ..</div>';
								}else{
									echo '<div class="alert alert-info">No Se Ingreso, Vuelva Intentarlo otra vez !</div>';
								}
							}

							}else{
      							echo 1;
   							}



						}else{
							echo 5;
						}
					}else{
						echo 6;
					}
					
				}else{
					echo 7;
				}
			}else{
				echo 8;
			}
		}else{
			echo 9;
		}
	}

//class="form-control select2" style="width: 100%;"


 ?>