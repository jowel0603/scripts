<?php 
	sleep(2);

	if ($_SERVER["REQUEST_METHOD"] == 'POST') {
		
		# code...
		if ($_POST["editperfil"] == 1 || $_POST["editperfil"] == 2 || $_POST["editperfil"] == 4) {
			# code...
			if (!empty($_POST["editnombre"])  && !empty($_POST["editidusuario"]) && !empty($_POST["edititarusuario"])  && !empty($_POST["edittipo_documento"]) && !empty($_POST["editdireccion"]) && !empty($_POST["editnum_documento"]) && !empty($_POST["edittelefono"]) && !empty($_POST["editcelular"]) && !empty($_POST["editemail"]) && !empty($_POST["editcargo"]) && !empty($_POST["editusuario"])  && !empty($_POST["permiso"])  ) {
			# code...
			
			if (preg_match('/^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ ]+$/', $_POST["editnombre"])) {
				# code...
				if (filter_var($_POST["editemail"], FILTER_VALIDATE_EMAIL)) {
					# code...
					if (strlen($_POST["editnum_documento"]) >= 13 || strlen($_POST["editnum_documento"]) >= 10 ) {
						# code...
						if (preg_match('/^[#\.\-a-zA-Z0-9 ]+$/', $_POST["editdireccion"])) {

							if (empty($_POST["clave2"])) {
								# code...
							
							
								
									require_once '../../funciones/funciones.php';




									$idusuarior = intval($_POST["editidusuario"]);
									$idusuariow = intval($_POST["edititarusuario"]);
									$nombre= strip_tags(htmlentities($_POST["editnombre"]));
									$tipo_documento = strip_tags(htmlentities($_POST["edittipo_documento"]));
									$direccion = strip_tags(htmlentities(trim($_POST["editdireccion"])));
									$num_documento = htmlspecialchars(((strip_tags($_POST['editnum_documento'], ENT_QUOTES))));
									$telefono = intval($_POST["edittelefono"]);
									$celular = intval($_POST["editcelular"]);
									$email = trim($_POST["editemail"]);
									$cargo = htmlspecialchars(strip_tags($_POST["editcargo"]));
									$usuario = htmlspecialchars(strip_tags($_POST["editusuario"]));
									$permiso = intval($_POST["permiso"]);
									$estado = intval($_POST["editestado"]);			
									$fecha = gmdate('Y-m-d H:i:s', hora_local(-5));


							
									//incluyo modelo
									require_once '../../modelos/Usuarios/mdlUsuarios.php';
									//instancio el modelo
									$usuarios = new ModeloUsuarios();


									
									$registroUsuario = $usuarios->editarUsuario($nombre,$tipo_documento,$num_documento,$celular,$telefono,$email,$direccion,$usuario,$cargo,$estado,$fecha,$_POST["permiso"],$idusuarior,$idusuariow);
		 
									if($registroUsuario == 0){
										echo $registroUsuario;

									}else if($registroUsuario == 3){
										echo $registroUsuario;
									}else if($registroUsuario == 4){
				    					echo $registroUsuario;
				    				}

								}else{


										require_once '../../funciones/funciones.php';



									if (validar_clave($_POST["clave2"])){

									$idusuarior = intval($_POST["editidusuario"]);
									$idusuariow = intval($_POST["edititarusuario"]);
									$nombre= strip_tags(htmlentities($_POST["editnombre"]));
									$tipo_documento = strip_tags(htmlentities($_POST["edittipo_documento"]));
									$direccion = strip_tags(htmlentities(trim($_POST["editdireccion"])));
									$num_documento = htmlspecialchars(((strip_tags($_POST['editnum_documento'], ENT_QUOTES))));
									$telefono = intval($_POST["edittelefono"]);
									$celular = intval($_POST["editcelular"]);
									$email = trim($_POST["editemail"]);
									$cargo = htmlspecialchars(strip_tags($_POST["editcargo"]));
									$usuario = htmlspecialchars(strip_tags($_POST["editusuario"]));
									$clave2 = sha1($_POST["clave2"]);
									$permiso = intval($_POST["permiso"]);
									$estado = intval($_POST["editestado"]);				
									$fecha = gmdate('Y-m-d H:i:s', hora_local(-5));

								
									   //incluyo modelo
									   require_once '../../modelos/Usuarios/mdlUsuarios.php';
									   //instancio el modelo
									   $usuarios = new ModeloUsuarios();





										
										$registroUsuario = $usuarios->editUsuario2($nombre,$tipo_documento,$num_documento,$celular,$telefono,$email,$direccion,$usuario,$clave2,$cargo,$estado,$fecha,$_POST["permiso"],$idusuarior,$idusuariow);
			 
										if($registroUsuario == 2){
											echo $registroUsuario;

											
										}else if($registroUsuario == 3){
											echo 3;
										}else if($registroUsuario == 4){
					    					echo 4;
					    				}



									}else{
										echo 1;
									}

		

								}

						}else{
							echo 5;
						}
					}else{
						echo 6;
					}
					
				}else{
					echo 7;
				}
			}else{
				echo 8;
			}
		}else{
			echo 9;
		}

		}else{
			echo 'No puede ejecutar esta acción';
		}
		
		
	}




 ?>