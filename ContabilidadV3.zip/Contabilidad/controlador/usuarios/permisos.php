<?php 


	try{

		

		require_once("../../modelos/Usuarios/mdlUsuarios.php");

        $usuario = new ModeloUsuarios();
        $mostrar = $usuario::listarpermisos();
        $valores=array();

        while ($reg=$mostrar->fetch(PDO::FETCH_OBJ)) {
			$sw=in_array($reg->idtipopermiso,$valores)?'checked':'';
			echo '<li><input type="checkbox" '.$sw.' name="permiso[]"  value="'.$reg->idtipopermiso.'">'.$reg->nombre.'</li>';
		}
// return the result in json
        

    }catch(Exception $ex){
    	echo "Error Al Mostrar Consulta Usuarios_Controller  --->  "+$e->getMessage();

    }catch (PDOException $ex)
	{
		 echo "Error Al Mostrar Consulta Usuarios_Controller  --->  "+$e->getMessage();
	}




 ?>