<?php 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	if (!empty($_POST["id"])) {
		# code...
		

		$id = strip_tags(htmlentities($_POST["id"]));
		require_once '../../modelos/Usuarios/mdlUsuarios.php';

		//instancio el modelo
		$usuarios = new ModeloUsuarios();

		$rspta=$usuarios->listarpermisos();


		$marcados=$usuarios->listarmarcados($id);
		$valores=array();

	//almacenar permisos asigandos
		while ($per=$marcados->fetch(PDO::FETCH_OBJ)) {
			array_push($valores, $per->idtipopermiso);
		}
				//mostramos la lista de permisos
		while ($reg=$rspta->fetch(PDO::FETCH_OBJ)) {
			
			$sw=in_array($reg->idtipopermiso,$valores)?'checked':'';
			echo '<li><input type="checkbox" '.$sw.' name="permiso[]" value="'.$reg->idtipopermiso.'">'.$reg->nombre.'</li>';

		}

				
	}else{
		echo 9;
	}

	
		

}else{
	echo 9;
}



 ?>