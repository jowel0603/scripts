<?php 

	if(!empty($_POST["id"])){

		if($_POST["estado"] == '1'){

			

			try{

				$estado = '0';
				$id=$_POST["id"];

				require_once("../../modelos/Usuarios/mdlUsuarios.php");

				$usuario = new ModeloUsuarios();
	        	$estadoupdate = $usuario::updateestado($id,$estado);

				if($estadoupdate){
					echo 8;
				}else {
					echo 9;
				}
				

		}catch(Exception $e){
			echo "Error Al Obtener UsuarioModel -->  " . $e->getMessage();
		}catch (PDOException $ex) {
            echo "Erron En La Consulta UsuarioModel --> " . $ex->getMessage();
        }



		}else if($_POST["estado"] == '0'){
			
			

			try{

				$estado = '1';
				$id=$_POST["id"];

				require_once("../../modelos/Usuarios/mdlUsuarios.php");

				$usuario = new ModeloUsuarios();
	        	$estadoupdate = $usuario::updateestado($id,$estado);

				if($estadoupdate){
					echo 8;
				}else {
					echo 9;
				}

			}catch(Exception $e){
				echo "Error Al Obtener UsuarioModel -->  " . $e->getMessage();
			}catch (PDOException $ex) {
            	echo "Erron En La Consulta UsuarioModel --> " . $ex->getMessage();
        	}
		}

		
		



		


	}else{
		echo 1;
	}



 ?>