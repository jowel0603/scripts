<?php
session_start();
$action = (isset($_REQUEST['action'])&& $_REQUEST['action'] !=NULL)?$_REQUEST['action']:'';
if($action == 'ajax'){
	$query = htmlspecialchars(((strip_tags($_REQUEST['query'], ENT_QUOTES))));

		require_once '../../conexion/conexion.php';
 
	/*------------------------------------------*/
	    $database=new Connection();
	    /*------------------------------------------*/
	    $db=$database->open();
		


		$tables="usuarios";
		$campos="*";
		$sWhere=" usuarios.nombre LIKE '%".$query."%' or usuarios.usuario LIKE '%".$query."%'  ";
		$sWhere.=" order by usuarios.id";

		
		
		
		include '../../funciones/pagination.php'; //include pagination file
		//pagination variables
		$page = (isset($_REQUEST['page']) && !empty($_REQUEST['page']))?$_REQUEST['page']:1;
		$per_page = intval($_REQUEST['per_page']); //how much records you want to show
		$adjacents  = 4; //gap between pages after number of adjacents
		$offset = ($page - 1) * $per_page;
		//Count the total number of row in your table*/
		$count_query   = $db->prepare("SELECT count(*) AS numrows FROM $tables where $sWhere ");
		$count_query->execute();

		$numrows=0; 
		
		if ($row=$count_query->fetch(PDO::FETCH_ASSOC)){
			$numrows = $row['numrows'];
		}
		else {
			echo mysqli_error($db, $count_query);
		}
		$total_pages = ceil($numrows/$per_page);
		//main query to fetch the data
		$query = $db->prepare("
			SELECT u.id, u.nombre, u.usuario, u.idrol, u.estado, r.idrol, r.nombre_rol
			FROM  usuarios u INNER JOIN roles r ON u.idrol = r.idrol 
			 
			  where u.nombre LIKE '%".$query."%' or u.usuario LIKE '%".$query."%'  LIMIT $offset,$per_page");
		$query->execute();
		//loop through fetched data
		
		
 
 
		
	
	if ($numrows>0){
		
	?>
		<div class="table-responsive">
			<table class="table table-striped table-hover tablas">
				<thead>
					<tr>
						<th>Nombre</th>
                        <th>Usuario</th>
                        <th>Perfil</th>
                        <th>Estado</th>
                        <th>Opciones</th>
					</tr>
				</thead>
				<tbody>	
						<?php 
						$finales=0;
						while($row =$query->fetch(PDO::FETCH_ASSOC)){	
							$nombre = $row["nombre"];
							$usuario = $row["usuario"];
							$nombrerol=$row['nombre_rol'];
							$estado=$row['estado'];
								
							$finales++;
						?>	
						<tr class="">
							<td class='text-center'><?php echo $nombre;?></td>
							<td ><?php echo $usuario;?></td>
							<td ><?php echo $nombrerol;?></td>
							<?php 

								if ($estado == 1) {
									# code...
									echo '<td><button class="btn btn-success btn-xs">Activo</button></td>';
								
							 ?>
							
							<?php }else{
								echo '<td><button class="btn btn-danger btn-xs">Inactivo</button></td>';
							} ?>
							<td>
								
									<?php

									echo '<button  class="btn btn-success btn-xs edit " data-id='.$row["id"].'<i style="font-size:12px" class="fa">&#xf021;</i></button>';
									
								
									 ?>
                            		
						           <?php 
						           echo '<button class="btn btn-primary btn-xs" onclick="estado('.$row['id'].',\''.$row['estado'].'\')"><i style="font-size:12px" class="fa">&#xf021;</i></button>'; 
						           ?>
						           
						           
                    		</td>
						</tr>
						<?php }?>
						<tr>
							<td colspan='8'> 
								<?php 
									$inicios=$offset+1;
									$finales+=$inicios -1;
									echo "Mostrando $inicios al $finales de $numrows registros";
									echo paginate( $page, $total_pages, $adjacents);
								?>
							</td>
						</tr>
				</tbody>			
			</table>
		</div>	


		  <!-- The Modal -->
            <div class="modal" id="edit">
              <div class="modal-dialog" style="width:70%">
                <div class="modal-content">

                  <!-- Modal Header -->
                  <div class="modal-header">
                    <h4 class="modal-title">Formulario Registrar Usuario</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    
                  </div>

                  <div id="mostrarDatos" style="color:green; text-align: center;" >
                           
                  </div>
                          

                  <div id="error" name="error" style="color:red; text-align: center;">
                    <!-- error will be shown here ! -->
                  </div> 
                  <div id="msg-alert" style="color:red; text-align: center;" >
                      
                  </div>
                    

                  <div style="display: none; text-align: center;" class="form-group d-none" id="gif">
                      <label><img src="../imagenes/ajax-loader.gif"> Procesando...</label>
                  </div>

                  <div class="modal-body">

                  <form name="formeditUsuario" id="formeditUsuario">
				  <input type="hidden" name="editperfil" id="editperfil" value="<?php echo $_SESSION["idrol"]; ?>">
                  <input type="hidden" name="editidusuario" id="editidusuario" value="<?php echo $_SESSION["id"]; ?>">
                  <input type="hidden" name="edititarusuario" id="edititarusuario">

                    <div class="nav-tabs-custom ">
                      <ul class="nav nav-tabs">
                        <li class="active"><a href="#activity" data-toggle="tab">Datos del Usuario</a></li> --
                        <li><a href="#settings" data-toggle="tab">Asignar Permisos</a></li>
                      </ul>

                      <div class="tab-content ">
                        <div class="active tab-pane" id="activity">

                        <div class="row">
                          <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <label>Nombre(*):</label>
                            <input type="text" class="form-control" name="editnombre" id="editnombre" maxlength="100" placeholder="Digite Nombre Completos"  autocomplete="off">
                          </div>
                          <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <label>Tipo Documento(*):</label>
                            <select class="form-control select-picker" name="edittipo_documento" id="edittipo_documento" >
                              <option value="DNI">DNI</option>
                              <option value="RUC">RUC</option>
                              <option value="CC">CEDULA</option>
                            </select>
                          </div>
                          <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <label>Número(*):</label>
                            <input type="text" class="form-control" name="editnum_documento" id="editnum_documento" maxlength="20" placeholder="Digite Numero de Documento"  autocomplete="off" onkeypress="return valideKey(event);" oninput="checkRut(this)">
                          </div>
                          <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <label>Dirección:</label>
                            <input type="text" class="form-control" name="editdireccion" id="editdireccion" placeholder="Digite Dirección" maxlength="70" autocomplete="off">
                          </div>
                          <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <label>Teléfono:</label>
                            <input type="text" class="form-control" name="edittelefono" id="edittelefono" maxlength="20" placeholder="Digite Teléfono" autocomplete="off" onkeypress="return valideKey(event);">
                          </div>

                        
                          <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <label>Email:</label>
                            <input type="text" class="form-control" name="editemail" id="editemail" maxlength="50" placeholder="Digite Email" autocomplete="off">
                          </div>
                          <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <label>Cargo:</label>
                            <select name="editcargo" id="editcargo" class="form-control" >
                                <option value="">Seleccione un Perfil</option>
                            <?php 

                              require_once "../../modelos/Usuarios/mdlUsuarios.php"; 

                              //instancio el modelo
                              $usuario = new ModeloUsuarios();

                              $listarperfiles = $usuario->mdlRoles();

                              foreach ($listarperfiles as $key => $data3) {
                                              # code...
                                              # 
                                  echo '<option value="'.$data3["idrol"].'">'.$data3["nombre_rol"].'</option>';

                              }

                            ?>  
                              
                              </select>
                          </div>

                          <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <label>Celular:</label>
                            <input type="text" class="form-control" name="editcelular" id="editcelular" maxlength="20" placeholder="Digite Celular" autocomplete="off" onkeypress="return valideKey(event);">
                          </div>


                          <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <label>Estado:</label>
                              <select name="editestado" id="editestado" class="form-control" >
                                <option value="">Seleccione un Estado</option>
                                <option value="1">Activo</option>
                                <option value="0">Inactivo</option>
                              </select>
                          </div>

                          </div>




                        </div>


                        <div class="tab-pane" id="settings">

						<div class="row">
							
					
                          <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <label>Usuario (*):</label>
                            <input type="text" class="form-control" name="editusuario" id="editusuario" maxlength="20" placeholder="Login"  autocomplete="off">
                          </div>
                          <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <label>Clave (*):</label>
                            <input type="password" class="form-control" name="editclave" id="editclave" maxlength="64" placeholder="6 caracteres, 1 mayuscula y un numero"  autocomplete="off" readonly="">
                          </div>

                          <div class='form-group col-lg-6 col-md-6 col-sm-6 col-xs-12'>
                              <label>Clave Nueva (*):</label>
                                <input type="password" class="form-control" name="clave2" id="clave2" maxlength="64" placeholder="6 caracteres, 1 mayuscula y un numero"  autocomplete="off">
                          </div>


                         


                        </div>

                         <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <label>Permisos:</label>
                            <ul name="permiso" id="permiso">
                              
                            </ul>
                          </div>


                    </div>


                            


                          
                          <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <button class="btn btn-primary" type="submit" id="btnEditarUsuario"><i class="fa fa-save"></i> Guardar</button>

                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                          </div>


                          </div><!-- /.tab-content -->
                        </div><!-- /.nav-tabs-custom -->

                      </div><!-- fin row -->

                    </form>

                </div>

         

            </div>
          </div>
        </div>

    <!--  fin modal add proveedor  --->

	
	<?php	
	}	else{
			//aqui muestro que no hay datos cuando esta buscando un usuario
			echo '<table class="table table-striped table-hover tablas">
					<thead>
						<tr>
						<th>Nombre</th>
                        <th>Usuario</th>
                        <th>Perfil</th>
                        <th>Estado</th>
                        <th>Opciones</th>
	                 </tr>
	                </thead>

	                <tbody>

	                <td>

	                <div  style="width: 200px; text-align: center;">
     						No hay datos
					</div>

					</td>
					</tbody>

					<tfooter>
					<tr>
						<th>Nombre</th>
                        <th>Usuario</th>
                        <th>Perfil</th>
                        <th>Estado</th>
                        <th>Opciones</th>
	                 </tr>
	                 </tfooter>

				</table>';
	}
}
?>   

<script type="text/javascript">
	$(function(){


		//accion al darle click editar al diario y muestra el modal
		$('.edit').click(function(e){
    		e.preventDefault();
		    $('#edit').modal('show');
		    var id = $(this).data('id');

		    //funcion get diario
		    getRow(id);
		    getRowpermisos(id);
  		});


		$('#btnEditarUsuario').on('click',function(evnt){
			evnt.preventDefault();

			let Formdata = $('#formeditUsuario').serialize();


			$.ajax({
				url: '../../controlador/usuarios/editarUsuario.php',
				type: 'POST',
				data: Formdata,
				dataType: 'html',
				async: true,
				cache:false,

				beforeSend: function(ob){
					$('#msg-alert').html('<div class="alert alert-info alert-dismissible fade show" role="alert">'+
  											'<strong>Información!  </strong>Actualizando datos, porfavor espere un momento.'+
				  							'<button type="button" class="close" data-dismiss="alert" aria-label="Close">'+
				    							'<span aria-hidden="true">&times;</span>'+
				  							'</button>'+
											'</div>');
				} ,
				success: function(respuesta){
					if (respuesta == 0) {
						$('#msg-alert').html('<div class="alert alert-success alert-dismissible fade show" role="alert">'+
  											'<strong>Exito!</strong> Actualizado Usuario correctamente.'+
				  							'<button type="button" class="close" data-dismiss="alert" aria-label="Close">'+
				    							'<span aria-hidden="true">&times;</span>'+
				  							'</button>'+
											'</div>');

						
						setTimeout(function(){location.reload();},2000);
					}else if(respuesta == 1){
						
						$('#msg-alert').html('<div class="alert alert-primary" role="alert">'+
					'La clave debe tener 6 caracteres, una letra mayuscula, otra minuscula, y un numero   :D.'+
									'</div>');


					}else if(respuesta == 2){
						
						$('#msg-alert').html('<div class="alert alert-info alert-dismissible fade show" role="alert">'+
  											'<strong>Información!  </strong>Actualizando datos, porfavor espere un momento.'+
				  							'<button type="button" class="close" data-dismiss="alert" aria-label="Close">'+
				    							'<span aria-hidden="true">&times;</span>'+
				  							'</button>'+
											'</div>');


					}else if (respuesta == 3) {
						$('#msg-alert').html('<div class="alert alert-danger alert-dismissible fade show" role="alert">'+
  											'<strong>ERROR!</strong> Error al actualizar los datos.'+
				  							'<button type="button" class="close" data-dismiss="alert" aria-label="Close">'+
				    							'<span aria-hidden="true">&times;</span>'+
				  							'</button>'+
											'</div>');
					}else if(respuesta == 4){
							$('#msg-alert').html('<div class="alert alert-danger alert-dismissible fade show" role="alert">'+
  											'<strong>ERROR!</strong>Ya hay un Registro de Usuario con este Email y/o Usuario o Numero documento.'+
				  							'<button type="button" class="close" data-dismiss="alert" aria-label="Close">'+
				    							'<span aria-hidden="true">&times;</span>'+
				  							'</button>'+
											'</div>');
					}else if(respuesta == 9){
							$('#msg-alert').html('<div class="alert alert-danger alert-dismissible fade show" role="alert">'+
  											'<strong>ERROR!</strong> Todos los campos son obligatorios.'+
				  							'<button type="button" class="close" data-dismiss="alert" aria-label="Close">'+
				    							'<span aria-hidden="true">&times;</span>'+
				  							'</button>'+
											'</div>');
					}else if(respuesta == 7){
							$('#msg-alert').html('<div class="alert alert-danger alert-dismissible fade show" role="alert">'+
  											'<strong>ERROR!</strong> Correo No valido .'+
				  							'<button type="button" class="close" data-dismiss="alert" aria-label="Close">'+
				    							'<span aria-hidden="true">&times;</span>'+
				  							'</button>'+
											'</div>');
					}else if(respuesta == 8){
							$('#msg-alert').html('<div class="alert alert-danger alert-dismissible fade show" role="alert">'+
  											'<strong>ERROR!</strong> Caracteres mayor de 10 .'+
				  							'<button type="button" class="close" data-dismiss="alert" aria-label="Close">'+
				    							'<span aria-hidden="true">&times;</span>'+
				  							'</button>'+
											'</div>');
					}else if(respuesta == 6){
							$('#msg-alert').html('<div class="alert alert-danger alert-dismissible fade show" role="alert">'+
  											'<strong>ERROR!</strong> Digite un documento valido .'+
				  							'<button type="button" class="close" data-dismiss="alert" aria-label="Close">'+
				    							'<span aria-hidden="true">&times;</span>'+
				  							'</button>'+
											'</div>');
					}

					
				}
			});
		});





	});
	//trae datos de diarios por id
	function getRow(id){
	  $.ajax({
	    type: 'POST',
	    url: '../../controlador/usuarios/getUsuario.php',
	    data: {id:id},
	    dataType: 'json',
	    success: function(response){
	    	$('#edititarusuario').val(response.id);
	    	$('#editnombre').val(response.nombre);
	    	$('#edittipo_documento').val(response.tipodocumento);
			$('#editnum_documento').val(response.n_documento);
			$('#editdireccion').val(response.direccion);
			$('#edittelefono').val(response.telefono);
			$('#editcelular').val(response.celular);
			$('#editemail').val(response.email);
			$('#editcargo').val(response.idrol);
			$('#editestado').val(response.estado);
			$('#editusuario').val(response.usuario);
			$('#editclave').val(response.password);
			$('#editidusuario').val(response.idusuario);

	      
	    }
	  });
	}

	//trae datos de diarios por id
	function getRowpermisos(id){
	  $.ajax({
	    type: 'POST',
	    url: '../../controlador/usuarios/getPermisos.php',
	    data: {id:id},
	    dataType: 'html',
	    success: function(response){
	    	$('#permiso').html(response);
	      
	    }
	  });
	}


	//funcion de RUT Cliente
function focusRutCliente()
{
    document.getElementById("num_documento").focus();
}

function isNumber(evt) {
  var charCode = evt.which ? evt.which : event.keyCode;
  if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode === 75) return false;

  return true;
}

function checkRut(rut) 
{

  if (rut.value.length <= 1) {
    mostrarDatos.classList.remove('alert-success', 'alert-danger');
    console.log(rut);
  }

  // Obtiene el valor ingresado quitando puntos y guiÃ³n.
  var valor = clean(rut.value);

  // Divide el valor ingresado en dÃ­gito verificador y resto del RUT.
  cuerpo = valor.slice(0, -1);
  dv = valor.slice(-1).toUpperCase();

  // Separa con un GuiÃ³n el cuerpo del dÃ­gito verificador.
  rut.value = format(rut.value);

  // Si no cumple con el mÃ­nimo ej. (n.nnn.nnn)
  if (cuerpo.length < 7) {
    rut.setCustomValidity("RUT Incompleto");
    console.clear();//FRONT-END
    return false;
  }

  // Calcular digito Verificador "metodo del MÃ³dulo 11"
  suma = 0;
  multiplo = 2;

  // Para cada digito del Cuerpo
  for (i = 1; i <= cuerpo.length; i++) {
    // Obtener su Producto con el MÃºltiplo Correspondiente
    index = multiplo * valor.charAt(cuerpo.length - i);

    // Sumar al Contador General
    suma = suma + index;

    // Consolidar Multiplo dentro del rango [2,7]
    if (multiplo < 7) {
      multiplo = multiplo + 1;
    } 
  else 
  {
        multiplo = 2;
    }
    
    
  }

  // Calcular Digito Verificador en base al Modulo 11
  dvEsperado = 11 - (suma % 11);

 // Casos Especiales (0 y K)
    dv = (dv == 'K')?10:dv;
    dv = (dv == 11)?0:dv;
  

  // Validar que el Cuerpo coincide con su DÃ­gito Verificador
  if (dvEsperado != dv) {
    rut.setCustomValidity('');
    $('#mostrarDatos').html('Rut Ingresado No es Valido').css('class="alert alert-success  alert-dismissible  " ');
    console.clear();
    return false;
  } 
  else 
  {

      rut.setCustomValidity('');
      $('#mostrarDatos').html('Rut Ingresado  es Valido').css('class="alert alert-success  alert-dismissible  " ');
      console.clear();//FRONT-END
      return true;
   
  }
}

function format (rut) {
  rut = clean(rut)

  var result = rut.slice(-4, -1) + '-' + rut.substr(rut.length - 1)
  for (var i = 4; i < rut.length; i += 3) {
    result = rut.slice(-3 - i, -i) + '.' + result
  }

  return result
}

function clean (rut) {
  return typeof rut === 'string'
    ? rut.replace(/^0+|[^0-9kK]+/g, '').toUpperCase()
    : ''
}


///funcion para validar input que permita solo numeros asi no dejamos que el usuario digite numeros negativos
function valideKey(evt) {
    let code = evt.which ? evt.which : evt.keyCode;
         if (code == 8) {
                    //backspace
             return true;
          } else if (code >= 48 && code <= 57) {
                    //is a number
             return true;
          } else {
             return false;
       }
 }




</script>  
