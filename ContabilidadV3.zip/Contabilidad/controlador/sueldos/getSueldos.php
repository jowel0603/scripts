<?php 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	if (!empty($_POST["id"])) {
		# code...
		$id = htmlspecialchars($_POST["id"]);
		require_once '../../modelos/sueldos/mdlSueldos.php';

		$miModelsueldos = new ModeloSueldos();

		$obtener = $miModelsueldos->getSueldo($id);


		echo json_encode($obtener);
	}

	
		

}else{
	echo 9;
}



 ?>