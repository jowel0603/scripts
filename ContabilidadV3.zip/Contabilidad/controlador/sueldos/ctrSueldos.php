<?php 
	sleep(1);
if ($_SERVER['REQUEST_METHOD'] == 'POST') {



	if(!empty($_POST["sueldo"]) && !empty($_POST["id_ocup"]) && !empty($_POST["id_empleado"]) && !empty($_POST["idusuario"]) && !empty($_POST["rut"]) ){

		if (strlen($_POST["sueldo"]) >= 9 && strlen($_POST["sueldo"]) == 9 || 
			strlen($_POST["sueldo"]) >= 7 && strlen($_POST["sueldo"]) == 7 || 
			strlen($_POST["sueldo"]) >= 10 && strlen($_POST["sueldo"]) == 10  || strlen($_POST["rut"]) >= 15 && strlen($_POST["rut"]) ==15     )
		{



				  	require_once '../../funciones/funciones.php';

				    /*----------------------------------------------*/
				    $sueldo=$_POST["sueldo"];
				    $idocupacion=$_POST["id_ocup"];
				    $idusuario=$_POST["idusuario"];
				    $rut=$_POST["rut"];
				    $id_empleado=$_POST["id_empleado"];
				    /*----------------------------------------------*/
				    $fecharegistro = gmdate('Y-m-d H:i:s', hora_local(-5));

				   		 require_once "../../modelos/sueldos/mdlSueldos.php";

				    	$miSueldo = new ModeloSueldos();


				    	$verificar = $miSueldo->verificarsueldo($idocupacion);

				    	if ($verificar->rowCount() > 0) 
				    	{
			                # code...
			               	echo 'error2';
			               	return false;
			                
			                
			            }
			            else
			            {

			            	 $registroSueldo = $miSueldo->registroSueldo($id_empleado, $rut, $sueldo, $idocupacion, $idusuario, $fecharegistro);

						    if($registroSueldo == 'ok')
						    {
						    	echo $registroSueldo;
						    }
						    else if($registroSueldo == 'error')
						    {
						    	echo $registroSueldo;
						    }
			            }

				  

			    	
			    }else{
			    	echo 8;
			    }

		}else{
			echo 9;
		}

		
	}else{
		echo 'Error Inesperado';
	}





 ?>