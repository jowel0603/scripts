<?php 
	sleep(1);
	

	if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	if(!empty($_POST["editarsueldo"]) && !empty($_POST["editid_ocup"]) && !empty($_POST["editaridusuario"]) && !empty($_POST["editaridsueldo"]) ){

		if (strlen($_POST["editarsueldo"]) >= 9 && strlen($_POST["editarsueldo"]) == 9 || strlen($_POST["editarsueldo"]) >= 7 && strlen($_POST["editarsueldo"]) == 7 ){
  				

			    	$editarsueldo=$_POST["editarsueldo"];
				    $editid_ocup=$_POST["editid_ocup"];
				    $editaridusuario=$_POST["editaridusuario"];
				    $editidsueldo=$_POST["editaridsueldo"];


				    require_once "../../modelos/sueldos/mdlSueldos.php";

				    	$miSueldo = new ModeloSueldos();

				    	

			           	$registroSueldo = $miSueldo::mdlEditarsueldo($editarsueldo,$editid_ocup,$editaridusuario,$editidsueldo);

						    if($registroSueldo == 'ok'){
						    	echo $registroSueldo;
						    }else if($registroSueldo == 'error'){
						    	echo $registroSueldo;
						    }else if($registroSueldo == 'error2'){
						    	echo $registroSueldo;
						    }
			            
	    
			    	
			    }else{
			    	echo 8;
			    }

		}else{
			echo 9;
		}

		
	}else{
		echo 'Error Inesperado';
	}





 ?>