<?php 

	

	require_once '../../modelos/ocupacion/mdlOcupacion.php';

	$miModelocupaciones = new ModeloOcupacion();
	$obtenerselectdatos = $miModelocupaciones->Ocupacion();


	return $obtenerselectdatos;









 ?>