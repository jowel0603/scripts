<?php 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	if (!empty($_POST["id"])) {
		# code...
		$id = htmlspecialchars($_POST["id"]);
		require_once '../../modelos/empresa/mdlEmpresa.php';

		$miModelempresa = new ModeloEmpresa();

		$obtener = $miModelempresa->getEmpresa($id);


		echo json_encode($obtener);
	}

	
		

}else{
	echo 9;
}



 ?>