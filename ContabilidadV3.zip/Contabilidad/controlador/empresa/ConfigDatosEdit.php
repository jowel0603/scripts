<?php 
	sleep(2);
if ($_SERVER['REQUEST_METHOD'] == 'POST') {



	if(!empty($_POST["nombre"]) && !empty($_POST["tipo_documento"]) && !empty($_POST["num_documento"]) && !empty($_POST["direccion"]) && !empty($_POST["telefono"]) && !empty($_POST["celular"]) && !empty($_POST["email"])  && !empty($_POST["idusuario"]) && !empty($_POST["idconfig"]) ){

		if (filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)) {


				  


    				require_once '../../funciones/funciones.php';
  				

			    	$nombre= strip_tags(htmlentities($_POST["nombre"]));
					$tipo_documento = strip_tags(htmlentities($_POST["tipo_documento"]));
					$direccion = strip_tags(htmlentities(trim($_POST["direccion"])));
					$num_documento = htmlspecialchars(((strip_tags($_POST['num_documento'], ENT_QUOTES))));
					$telefono = intval($_POST["telefono"]);
					$celular = intval($_POST["celular"]);
					$email = trim($_POST["email"]);
				    $usuario=intval($_POST["idusuario"]);
				    $idconfig = intval($_POST["idconfig"]);
				    $fecha = gmdate('Y-m-d H:i:s', hora_local(-5));

				    require_once "../../modelos/empresa/mdlEmpresa.php";

				    $miEmpresa = new ModeloEmpresa();


			        $registroEmpresa = $miEmpresa::mdlIngresarConfigDatosEditar($nombre,$tipo_documento,$num_documento,$celular,$telefono,$email,$direccion,$usuario, $fecha, $idconfig);

					if($registroEmpresa == 1){
						echo $registroEmpresa;
					}else if($registroEmpresa == 2){
						echo $registroEmpresa;
					}
			            

			    	
			    }else{
			    	echo 8;
			    }

		}else{
			echo 9;
		}

		
	}else{
		echo 'Error Inesperado';
	}





 ?>