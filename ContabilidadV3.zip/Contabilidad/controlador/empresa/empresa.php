<?php 


	require_once("../../modelos/empresa/mdlEmpresa.php");

    $prove = new ModeloEmpresa();
    $mostrar = $prove::Empresas();




 ?>