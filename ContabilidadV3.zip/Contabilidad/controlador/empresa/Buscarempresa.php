<?php 
	

	try {

		$idempresa =  $_POST["search"];


		//modelo require_once
		require_once('../../modelos/empresa/mdlEmpresa.php');


		//instancio modelo
		$mdlEmpresa = new ModeloEmpresa();
		$obtener = $mdlEmpresa->Buscarempresa($idempresa);

		$response = array();

		while($row = $obtener->fetch(PDO::FETCH_ASSOC)){

		 $response[] = array("value"=>$row['idempresa'],"label"=>$row['nombre']);

		}


		//if para saber si existe
		//
		

		echo json_encode($response);
 			
	} catch (Exception $e) {
		echo 'Error en el controllador empresa --> '.$e->getMessage();
	}





 ?>