<?php 
	sleep(1);
if ($_SERVER['REQUEST_METHOD'] == 'POST') {



	if(!empty($_POST["empresa"]) && !empty($_POST["nit"]) && !empty($_POST["direccion"]) && !empty($_POST["telefono"]) && !empty($_POST["celular"]) && !empty($_POST["correo"])  ){

		if (filter_var($_POST["correo"], FILTER_VALIDATE_EMAIL)) {


				  


    				require_once '../../funciones/funciones.php';
  				

			    	$nombre=htmlspecialchars(addslashes(ucwords($_POST["empresa"])));
				    $ruc=$_POST["nit"];
				    $direccion=htmlspecialchars(addslashes($_POST["direccion"]));
				    $telefono=$_POST["telefono"];
				    $celular=$_POST["celular"];
				    $email=trim($_POST["correo"]);
				    $usuario=$_POST["idusuario"];
				    $fecha = gmdate('Y-m-d H:i:s', hora_local(-5));

				    	require_once "../../modelos/empresa/mdlEmpresa.php";

				    	$miEmpresa = new ModeloEmpresa();


				    	$verificar = $miEmpresa->verificarnitempresa($ruc);
				    	$verificar2 = $miEmpresa->verificarcorreoempresa($email);

				    	if ($verificar->rowCount() > 0) {
			                # code...
			               	echo 'error2';
			               	return false;
			                
			                
			            }else if($verificar2->rowCount() > 0){
			               	echo 'error2';
			                return false;
			            }else{

			            	 $registroEmpresa = $miEmpresa::mdlIngresarEmpresa($nombre,$ruc,$direccion,$telefono,$celular,$email,$usuario, $fecha);

						    if($registroEmpresa == 'ok'){
						    	echo $registroEmpresa;
						    }else if($registroEmpresa == 'error'){
						    	echo $registroEmpresa;
						    }
			            }




			            	
			            



				    
			    	
			    }else{
			    	echo 8;
			    }

		}else{
			echo 9;
		}

		
	}else{
		echo 'Error Inesperado';
	}





 ?>