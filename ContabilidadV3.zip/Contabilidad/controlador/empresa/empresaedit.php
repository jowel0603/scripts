<?php 
	sleep(1);
	

	if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	if(!empty($_POST["editaridempresa"]) && !empty($_POST["editaridusuario"]) && !empty($_POST["editarempresa"]) && !empty($_POST["editarnit"]) && !empty($_POST["editardireccion"]) && !empty($_POST["editartelefono"]) && !empty($_POST["editarcelular"]) && !empty($_POST["editarcorreo"])   ){

		if (filter_var($_POST["editarcorreo"], FILTER_VALIDATE_EMAIL)) {
  				

			    	$nombre=htmlspecialchars(addslashes(ucwords($_POST["editarempresa"])));
				    $ruc=$_POST["editarnit"];
				    $direccion=htmlspecialchars(addslashes($_POST["editardireccion"]));
				    $telefono=$_POST["editartelefono"];
				    $celular=$_POST["editarcelular"];
				    $email=trim($_POST["editarcorreo"]);
				    $usuario=$_POST["editaridusuario"];
				    $idempresa = $_POST["editaridempresa"];

				    	require_once "../../modelos/empresa/mdlEmpresa.php";

				    	$miEmpresa = new ModeloEmpresa();



			           	$registroEmpresa = $miEmpresa::mdlEditarempresa($nombre,$ruc,$direccion,$telefono,$celular,$email,$usuario,$idempresa);

						    if($registroEmpresa == 'ok'){
						    	echo $registroEmpresa;
						    }else if($registroEmpresa == 'error'){
						    	echo $registroEmpresa;
						    }else if($registroEmpresa == 'error2'){
						    	echo $registroEmpresa;
						    }
			            
	    
			    	
			    }else{
			    	echo 8;
			    }

		}else{
			echo 9;
		}

		
	}else{
		echo 'Error Inesperado';
	}





 ?>