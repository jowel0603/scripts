<?php 
		

		try {

			$criterio = htmlspecialchars(trim($_POST["codigocuenta"]));

			require_once("../../modelos/asientoscontables/mdlAsientoscontables.php");

        	$mdlAsientos = new ModeloAsientos();
        	$mostrar = $mdlAsientos::BuscarAsiento($criterio);


        	

        	echo json_encode($mostrar);
			
		} catch (Exception $e) {
			echo "Error Al Mostrar Consulta Asientos Contable  --->  "+$e->getMessage();
		}catch (PDOException $ex)
		{
			  
			echo "Error Al Mostrar Consulta Asientos Contable  --->  "+$ex->getMessage();
			 
		}
		




 ?>