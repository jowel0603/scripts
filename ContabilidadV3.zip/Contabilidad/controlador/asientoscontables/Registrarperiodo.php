<?php 
	sleep(1);
if ($_SERVER['REQUEST_METHOD'] == 'POST') {



	if(!empty($_POST["fechainicial"]) && !empty($_POST["fechafinal"]) && !empty($_POST["codigo"]) && !empty($_POST["estado"]) && !empty($_POST["idusuario"]) ){

		


    				require_once '../../funciones/funciones.php';
  				

			    	$codigo=htmlspecialchars(addslashes($_POST["codigo"]));
				    $fechainicial=htmlspecialchars(addslashes($_POST["fechainicial"]));
				    $fechafinal=htmlspecialchars(addslashes($_POST["fechafinal"]));
				    $estado = intval($_POST["estado"]);
				    $usuario=intval($_POST["idusuario"]);
				    $fecha = gmdate('Y-m-d H:i:s', hora_local(-5));

				    	require_once "../../modelos/asientoscontables/mdlAsientoscontables.php";

				    	$mdlAsientosperiodos = new ModeloAsientos();


				    	$verificar = $mdlAsientosperiodos->verificarCodigo($codigo);

				    	if ($verificar->rowCount() > 0) {
			                # code...
			               	echo 'error2';
			               	return false;
			                
			                
			            }else{

			            	 $registroPeriodo = $mdlAsientosperiodos::mdlIngresarperido($fechainicial,$fechafinal,$codigo,$estado,$usuario,$fecha);

						    if($registroPeriodo == 'ok'){
						    	echo $registroPeriodo;
						    }else if($registroPeriodo == 'error'){
						    	echo $registroPeriodo;
						    }
			            }



		}else{
			echo 9;
		}

		
	}else{
		echo 'Error Inesperado';
	}





 ?>