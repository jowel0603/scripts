<?php 
	sleep(1);
if ($_SERVER['REQUEST_METHOD'] == 'POST') {



	if(!empty($_POST["fecha"]) && !empty($_POST["idtipoperiodo"]) && !empty($_POST["idtipodiario"]) && !empty($_POST["idempresa"]) && !empty($_POST["estado"]) && !empty($_POST["concepto"]) && !empty($_POST["referencia"]) && !empty($_POST["codigocuenta"]) && !empty($_POST["nombrecuenta"]) && !empty($_POST["debe"]) && !empty($_POST["haber"]) && !empty($_POST["idusuario"])){

		//if (filter_var($_POST["correo"], FILTER_VALIDATE_EMAIL)) {


				  


    				require_once '../../funciones/funciones.php';
  				

			    	$fecha=htmlspecialchars(trim($_POST["fecha"]));
				    $idtipoperiodo=intval($_POST["idtipoperiodo"]);
				    $idtipodiario=intval($_POST["idtipodiario"]);
				    $idempresa=intval($_POST["idempresa"]);
				    $estado=intval($_POST["estado"]);    
				    $concepto=htmlspecialchars(trim($_POST["concepto"]));
				    $referencia=htmlspecialchars(trim($_POST["referencia"]));
				    $codigocuenta=intval($_POST["codigocuenta"]); 
				    $nombrecuenta=$_POST["nombrecuenta"];
				    $debe = $_POST["debe"];
				    $haber = $_POST["haber"];
				    $idusuario=intval($_POST["idusuario"]);
				    $fechar = gmdate('Y-m-d H:i:s', hora_local(-5));

				    	require_once "../../modelos/asientoscontables/mdlAsientoscontables.php";

				    	$mdlAsientoscontables = new ModeloAsientos();


				    	$verificar = $mdlAsientoscontables->verificarCodigoasiento($referencia);

				    	if ($verificar->rowCount() > 0) {
			                # code...
			               	echo 'error2';
			               	return false;
			                
			                
			            }else{

			            	 $registroAsientos = $mdlAsientoscontables::mdlIngresarAsientoscontable($fecha,$idtipoperiodo,$idtipodiario,$idempresa,$estado,$concepto,$referencia,$codigocuenta,$nombrecuenta,$debe,$haber,$idusuario,$fechar);

						    if($registroAsientos == 'ok'){
						    	echo $registroAsientos;
						    }else if($registroAsientos == 'error'){
						    	echo $registroAsientos;
						    }
			            }




			            	
			            



				    
			    	
			   /* }else{
			    	echo 8;
			    }*/

		}else{
			echo 9;
		}

		
	}else{
		echo 'Error Inesperado';
	}





 ?>