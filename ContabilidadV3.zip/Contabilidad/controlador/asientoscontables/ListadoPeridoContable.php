<?php
session_start();
$action = (isset($_REQUEST['action'])&& $_REQUEST['action'] !=NULL)?$_REQUEST['action']:'';
if($action == 'ajax'){
	$query = htmlspecialchars(((strip_tags($_REQUEST['query'], ENT_QUOTES))));

		require_once '../../conexion/conexion.php';
 
	/*------------------------------------------*/
	    $database=new Connection();
	    /*------------------------------------------*/
	    $db=$database->open();
		


		$tables="periodo_contables";
		$campos="*";
		$sWhere=" periodo_contables.codigo LIKE '%".$query."%' or periodo_contables.estado LIKE '%".$query."%' or periodo_contables.fecha_inicial LIKE '%".$query."%'  ";
		$sWhere.=" order by periodo_contables.codigo";

		
		
		
		include '../../funciones/pagination.php'; //include pagination file
		//pagination variables
		$page = (isset($_REQUEST['page']) && !empty($_REQUEST['page']))?$_REQUEST['page']:1;
		$per_page = intval($_REQUEST['per_page']); //how much records you want to show
		$adjacents  = 4; //gap between pages after number of adjacents
		$offset = ($page - 1) * $per_page;
		//Count the total number of row in your table*/
		$count_query   = $db->prepare("SELECT count(*) AS numrows FROM $tables where $sWhere ");
		$count_query->execute();

		$numrows=0; 
		
		if ($row=$count_query->fetch(PDO::FETCH_ASSOC)){
			$numrows = $row['numrows'];
		}
		else {
			echo mysqli_error($db, $count_query);
		}
		$total_pages = ceil($numrows/$per_page);
		//main query to fetch the data
		$query = $db->prepare("
			SELECT p.idperiodo, p.fecha_inicial, p.fecha_final, p.Codigo, p.estado, e.idestado, e.nombre 
			FROM  periodo_contables p
			 INNER JOIN estado e ON p.estado = e.idestado
			  
			  where p.fecha_inicial LIKE '%".$query."%' or p.Codigo LIKE '%".$query."%'  LIMIT $offset,$per_page");
		$query->execute();
		//loop through fetched data
		
		
 
 
		
	
	if ($numrows>0){
		
	?>
		<div class="table-responsive">
			<table class="table table-striped table-hover tablas">
				<thead>
					<tr>
						<th>Fecha Inicial</th>
                        <th>Fecha Final</th>
                        <th>Codigo</th>
                        <th>Estado</th>
                        <th>Opciones</th>
					</tr>
				</thead>
				<tbody>	
						<?php 
						$finales=0;
						while($row =$query->fetch(PDO::FETCH_ASSOC)){	
							$idperiodo = $row["idperiodo"];
							$fecha_inicial=$row['fecha_inicial'];
							$fecha_final=$row['fecha_final'];
							$codigo=$row['Codigo'];
							$estado=$row['nombre'];					
							$finales++;
						?>	
						<tr class="">
							<td class='text-center'><?php echo $fecha_inicial;?></td>
							<td ><?php echo $fecha_final;?></td>
							<td ><?php echo $codigo;?></td>
							<td ><?php echo $estado;?></td>
							
							<td>
								
									<button class="btn btn-success btn-xs edit btn-flat" data-id="<?php echo $row['idperiodo']; ?>"><i class="fa fa-edit"></i> Editar</button>
						           
						           
						           
                    		</td>
						</tr>
						<?php }?>
						<tr>
							<td colspan='8'> 
								<?php 
									$inicios=$offset+1;
									$finales+=$inicios -1;
									echo "Mostrando $inicios al $finales de $numrows registros";
									echo paginate( $page, $total_pages, $adjacents);
								?>
							</td>
						</tr>
				</tbody>			
			</table>
		</div>	


		<!-- MODAL EDITAR  -->
		<!-- The Modal -->
		<div class="modal" id="edit">
		  <div class="modal-dialog">
		    <div class="modal-content">

		      <!-- Modal Header -->
		      <div class="modal-header">
		        <h4 class="modal-title">Formulario Editar Periodo</h4>
		        <button type="button" class="close" data-dismiss="modal">&times;</button>
		        
		      </div>
		      <div id="msg-info">
		          
		      </div>

		      <!-- Modal body -->
		      <div class="modal-body">
		        <form id="editPeriodo" name="editPeriodo" class="form-horizontal"  >
		          <input type="hidden" class="form-control" id="editaridusuario" name="editaridusuario" value="<?php echo $_SESSION["id"];  ?>" >
		          <input type="hidden" class="form-control" id="editidperiodo" name="editidperiodo" value="" >


		                <div class="form-group">
                                    <label for="sueldo" class="col-sm-3 control-label">Fecha Inicial</label>

                                    <div class="col-md-12">
                                      <input type="date" class="form-control" id="editfechainicial"  name="editfechainicial" autocomplete="off" >
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="perfil" class="col-sm-3 control-label">Fecha Final</label>
                                    <div class="col-md-12">
                                      <input type="date" id="editfechafinal" name="editfechafinal" placeholder="Digite nuevo diario" autocomplete="off" class="form-control">
                                    </div>
                                </div>


                                <div class="form-group">
                                    <label for="perfil" class="col-sm-3 control-label">Codigo</label>
                                    <div class="col-md-12">
                                      <input type="text" id="editcodigo" name="editcodigo" placeholder="Digite nuevo diario" autocomplete="off" class="form-control">
                                    </div>
                                </div>

                                 <div class="form-group">
                                    <label for="perfil" class="col-sm-3 control-label">Estado</label>
                                    <div class="col-md-12">
                                      <select class="form-control select2" name="editestado" id="editestado" required  style="width: 100%;">
                                        <option  >Sleccione un Estado</option>
                                            <?php


                                            require_once '../../modelos/asientoscontables/mdlAsientoscontables.php';

                                            $mdlAsientos = new ModeloAsientos();
                                            $obtenerestado = $mdlAsientos->Estado();


                                            foreach ($obtenerestado as $key => $data3) {
                                                        # code...
                                                        # 
                                            echo '<option value="'.$data3["idestado"].'">'.$data3["nombre"].'</option>';

                                                    }
                                              ?>
                                      </select>
                                    </div>
                                </div>
		                
		                
		                
		            </div>
		            <div class="modal-footer">
		              <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
		              <button type="submit" class="btn btn-primary btn-flat editarPeriodo"><i class="fa fa-check-square-o"></i>Actualizar</button>
		              
		     	 	</div>

		      </form>

		      

		    </div>
		  </div>
		</div>





	
	<?php	
	}	else{
			//aqui muestro que no hay datos cuando esta buscando un usuario
			echo '<table class="table table-striped table-hover tablas">
					<thead>
						<tr>
	                    <th>Fecha Inicial</th>
                        <th>Fecha Final</th>
                        <th>Codigo</th>
                        <th>Estado</th>
                        <th>Opciones</th>
	                 </tr>
	                </thead>

	                <tbody>

	                <td>

	                <div  style="width: 200px; text-align: center;">
     						No hay datos
					</div>

					</td>
					</tbody>

					<tfooter>
					<tr>
	                    <th>Fecha Inicial</th>
                        <th>Fecha Final</th>
                        <th>Codigo</th>
                        <th>Estado</th>
                        <th>Opciones</th>
	                 </tr>
	                 </tfooter>

				</table>';
	}
}
?>     
<script type="text/javascript">
	$(function(){


		//accion al darle click editar al periodo contable y muestra el modal
		$('.edit').click(function(e){
    		e.preventDefault();
		    $('#edit').modal('show');
		    var id = $(this).data('id');

		    //funcion get periodo
		    getRow(id);
  		});


		$('.editarPeriodo').on('click',function(evnt){
			evnt.preventDefault();

			let Formdata = $('#editPeriodo').serialize();


			$.ajax({
				url: '../../controlador/asientoscontables/editarPeriodoContable.php',
				type: 'POST',
				data: Formdata,
				dataType: 'html',
				async: true,
				cache:false,

				beforeSend: function(ob){
					$('#msg-info').html('<div class="alert alert-info alert-dismissible fade show" role="alert">'+
  											'<strong>Información!  </strong>Actualizando datos, porfavor espere un momento.'+
				  							'<button type="button" class="close" data-dismiss="alert" aria-label="Close">'+
				    							'<span aria-hidden="true">&times;</span>'+
				  							'</button>'+
											'</div>');
				} ,
				success: function(respuesta){
					if (respuesta == 'ok') {
						$('#msg-info').html('<div class="alert alert-success alert-dismissible fade show" role="alert">'+
  											'<strong>Exito!</strong> Actualizado Periodo Contable correctamente.'+
				  							'<button type="button" class="close" data-dismiss="alert" aria-label="Close">'+
				    							'<span aria-hidden="true">&times;</span>'+
				  							'</button>'+
											'</div>');

						
						setTimeout(function(){location.reload();},2000);
					}else if (respuesta == 'error') {
						$('#msg-info').html('<div class="alert alert-danger alert-dismissible fade show" role="alert">'+
  											'<strong>ERROR!</strong> Error al actualizar los datos.'+
				  							'<button type="button" class="close" data-dismiss="alert" aria-label="Close">'+
				    							'<span aria-hidden="true">&times;</span>'+
				  							'</button>'+
											'</div>');
					}else if(respuesta == 'error2'){
							$('#msg-info').html('<div class="alert alert-danger alert-dismissible fade show" role="alert">'+
  											'<strong>ERROR!</strong>Ya hay un Registro de Periodo con este Codigo.'+
				  							'<button type="button" class="close" data-dismiss="alert" aria-label="Close">'+
				    							'<span aria-hidden="true">&times;</span>'+
				  							'</button>'+
											'</div>');
					}else if(respuesta == '9'){
							$('#msg-info').html('<div class="alert alert-danger alert-dismissible fade show" role="alert">'+
  											'<strong>ERROR!</strong> Todos los campos son obligatorios.'+
				  							'<button type="button" class="close" data-dismiss="alert" aria-label="Close">'+
				    							'<span aria-hidden="true">&times;</span>'+
				  							'</button>'+
											'</div>');
					}

					
				}
			});
		});





	});
		//trae datos de diarios por id
function getRow(id){
	  $.ajax({
	    type: 'POST',
	    url: '../../controlador/asientoscontables/getPeriodocontable.php',
	    data: {id:id},
	    dataType: 'json',
	    success: function(response){
	    	$('#editidperiodo').val(response.idperiodo);
	    	$('#editfechainicial').val(response.fecha_inicial);
			$('#editfechafinal').val(response.fecha_inicial);
			$('#editcodigo').val(response.Codigo);
			$('#editestado').val(response.estado);
			$('#editaridusuario').val(response.idusuario);
	      
	    }
	  });
}
</script>  
