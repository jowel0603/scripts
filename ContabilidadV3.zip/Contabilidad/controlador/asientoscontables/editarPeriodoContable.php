<?php 
	sleep(1);
if ($_SERVER['REQUEST_METHOD'] == 'POST') {



	if(!empty($_POST["editfechainicial"]) && !empty($_POST["editfechafinal"]) && !empty($_POST["editcodigo"]) && !empty($_POST["editestado"]) && !empty($_POST["editaridusuario"]) && !empty($_POST["editidperiodo"]) ){

		


    				require_once '../../funciones/funciones.php';
  					
    				$idperiodo=intval($_POST["editidperiodo"]);
			    	$codigo=htmlspecialchars(addslashes($_POST["editcodigo"]));
				    $fechainicial=htmlspecialchars(addslashes($_POST["editfechainicial"]));
				    $fechafinal=htmlspecialchars(addslashes($_POST["editfechafinal"]));
				    $estado = intval($_POST["editestado"]);
				    $usuario=intval($_POST["editaridusuario"]);
				    $fecha = gmdate('Y-m-d H:i:s', hora_local(-5));

				    	require_once "../../modelos/asientoscontables/mdlAsientoscontables.php";

				    	$mdlAsientosperiodos = new ModeloAsientos();


				    	

			            	 $registroPeriodo = $mdlAsientosperiodos::mdlEditarPeriodo($fechainicial,$fechafinal,$codigo,$estado,$usuario,$fecha,$idperiodo);

						    if($registroPeriodo == 'ok'){
						    	echo $registroPeriodo;
						    }else if($registroPeriodo == 'error'){
						    	echo $registroPeriodo;
						    }else if($registroPeriodo == 'error2'){
						    	echo $registroPeriodo;
						    }
			            



		}else{
			echo 9;
		}

		
	}else{
		echo 'Error Inesperado';
	}





 ?>