<?php
session_start();
$action = (isset($_REQUEST['action'])&& $_REQUEST['action'] !=NULL)?$_REQUEST['action']:'';
if($action == 'ajax'){
	$query = htmlspecialchars(((strip_tags($_REQUEST['query'], ENT_QUOTES))));

		require_once '../../conexion/conexion.php';
 
	/*------------------------------------------*/
	    $database=new Connection();
	    /*------------------------------------------*/
	    $db=$database->open();
		


		$tables="plan_cuenta";
		$campos="*";
		$sWhere=" plan_cuenta.n_digitos LIKE '%".$query."%' or plan_cuenta.nombre LIKE '%".$query."%'  ";
		$sWhere.=" order by plan_cuenta.n_digitos";

		
		
		
		include '../../funciones/pagination.php'; //include pagination file
		//pagination variables
		$page = (isset($_REQUEST['page']) && !empty($_REQUEST['page']))?$_REQUEST['page']:1;
		$per_page = intval($_REQUEST['per_page']); //how much records you want to show
		$adjacents  = 4; //gap between pages after number of adjacents
		$offset = ($page - 1) * $per_page;
		//Count the total number of row in your table*/
		$count_query   = $db->prepare("SELECT count(*) AS numrows FROM $tables where $sWhere ");
		$count_query->execute();

		$numrows=0; 
		
		if ($row=$count_query->fetch(PDO::FETCH_ASSOC)){
			$numrows = $row['numrows'];
		}
		else {
			echo mysqli_error($db, $count_query);
		}
		$total_pages = ceil($numrows/$per_page);
		//main query to fetch the data
		$query = $db->prepare("
			SELECT c.idcc, c.p_digito, c.nombre, g.idg, g.n_digitos, g.nombre_grupo, p.idc, p.codigoclase, p.grupoid, g.n_digitos, p.nombre 
			FROM  plan_cuenta p
			 INNER JOIN clase_cuenta c ON p.codigoclase = c.idcc
			  INNER JOIN grupo g ON p.grupoid = g.idg 
			  where p.n_digitos LIKE '%".$query."%' or p.nombre LIKE '%".$query."%'  LIMIT $offset,$per_page");
		$query->execute();
		//loop through fetched data
		
		
 
 
		
	
	if ($numrows>0){
		
	?>
		<div class="table-responsive">
			<table class="table table-striped table-hover tablas">
				<thead>
					<tr>
						<th>Clase Cuenta</th>
                        <th>Grupo Cuenta</th>
                        <th>Cuenta</th>
                        <th>Nombre</th>
                        <th>Opciones</th>
					</tr>
				</thead>
				<tbody>	
						<?php 
						$finales=0;
						while($row =$query->fetch(PDO::FETCH_ASSOC)){	
							$idc = $row["idc"];
							$codigoclase=$row['nombre'];
							$grupoid=$row['nombre_grupo'];
							$n_digitos=$row['n_digitos'];
							$nombre=$row['nombre'];					
							$finales++;
						?>	
						<tr class="">
							<td class='text-center'><?php echo $codigoclase;?></td>
							<td ><?php echo $grupoid;?></td>
							<td ><?php echo $n_digitos;?></td>
							<td ><?php echo $nombre;?></td>
							
							<td>
								
									<?php

									echo '<a href="updateUsuarios.php?idc='.$row["idc"].'""  type="button" > <i class="glyphicon glyphicon-edit"></i></a>'; 
								
									 ?>
                            		
						           
						           
						           
                    		</td>
						</tr>
						<?php }?>
						<tr>
							<td colspan='8'> 
								<?php 
									$inicios=$offset+1;
									$finales+=$inicios -1;
									echo "Mostrando $inicios al $finales de $numrows registros";
									echo paginate( $page, $total_pages, $adjacents);
								?>
							</td>
						</tr>
				</tbody>			
			</table>
		</div>	



	
	<?php	
	}	else{
			//aqui muestro que no hay datos cuando esta buscando un usuario
			echo '<table class="table table-striped table-hover tablas">
					<thead>
						<tr>
	                    <th>Clase Cuenta</th>
                        <th>Grupo Cuenta</th>
                        <th>Cuenta</th>
                        <th>Nombre</th>
                        <th>Opciones</th>
	                 </tr>
	                </thead>

	                <tbody>

	                <td>

	                <div  style="width: 200px; text-align: center;">
     						No hay datos
					</div>

					</td>
					</tbody>

					<tfooter>
					<tr>
	                    <th>Clase Cuenta</th>
                        <th>Grupo Cuenta</th>
                        <th>Cuenta</th>
                        <th>Nombre</th>
                        <th>Opciones</th>
	                 </tr>
	                 </tfooter>

				</table>';
	}
}
?>     
