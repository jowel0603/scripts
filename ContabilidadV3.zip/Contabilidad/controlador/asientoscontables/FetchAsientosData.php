<?php 

	try {
		//incluyo el modelo
		//
		require_once '../../modelos/asientoscontables/mdlAsientoscontables.php';

		$mdlAsiento = new ModeloAsientos();

		$obtener = $mdlAsiento->mdlMostrarAsientos();

		echo json_encode($obtener);
		




	} catch (Exception $e) {
		echo 'Error a la consulta --> '.$e->getMessage();
	}

 ?>