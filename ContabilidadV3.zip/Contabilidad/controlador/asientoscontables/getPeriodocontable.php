<?php 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	if (!empty($_POST["id"])) {
		# code...
		$id = htmlspecialchars($_POST["id"]);


		require_once '../../modelos/asientoscontables/mdlAsientoscontables.php';

		$mdlPeriodo = new ModeloAsientos();

		$obtener = $mdlPeriodo->getPeriodo($id);


		echo json_encode($obtener);
	}

	
		

}else{
	echo 9;
}



 ?>