<?php 
	sleep(1);
if ($_SERVER['REQUEST_METHOD'] == 'POST') {



	if(!empty($_POST["nombres"]) && !empty($_POST["apellidos"]) && !empty($_POST["direccion"]) && !empty($_POST["telefono"]) && !empty($_POST["celular"]) && !empty($_POST["cod_dpto"]) && !empty($_POST["empresa"]) && !empty($_POST["cod_mun"]) && !empty($_POST["usuario"]) && !empty($_POST["rut"]) && !empty($_POST["genero"])){

		//if (filter_var($_POST["correo"], FILTER_VALIDATE_EMAIL)) {


				  


    				require_once '../../funciones/funciones.php';
  				

			    	$nombre=htmlspecialchars(addslashes(ucwords($_POST["nombres"])));
				    $apellidos=htmlspecialchars(addslashes(ucwords($_POST["apellidos"])));
				    $rut=$_POST["rut"];
				    $genero=htmlspecialchars($_POST["genero"]);
				    $direccion=htmlspecialchars(addslashes($_POST["direccion"]));
				    $telefono=$_POST["telefono"];
				    $celular=$_POST["celular"];
				    $cod_dpto=$_POST["cod_dpto"];
				    $cod_mun=$_POST["cod_mun"];
				    $empresa =$_POST["empresa"];
				    $usuario=intval($_POST["usuario"]);
				    
				    $fecha = gmdate('Y-m-d H:i:s', hora_local(-5));

				    	require_once "../../modelos/empleado/mdlEmpleado.php";

				    	$miModelempleado = new ModeloEmpleado();


				    	$verificar = $miModelempleado->verificarnitempleado($rut);

				    	if ($verificar->rowCount() > 0) {
			                # code...
			               	echo 'error2';
			               	return false;
			                
			                
			            }else{

			            	 $registroEmpleado = $miModelempleado::mdlIngresarEmpleado($nombre,$apellidos,$rut,$direccion,$telefono,$celular,$cod_dpto,$cod_mun,$empresa,$usuario,$fecha,$genero);

						    if($registroEmpleado == 'ok'){
						    	echo $registroEmpleado;
						    }else if($registroEmpleado == 'error'){
						    	echo $registroEmpleado;
						    }
			            }




			            	
			            



				    
			    	
			   /* }else{
			    	echo 8;
			    }*/

		}else{
			echo 9;
		}

		
	}else{
		echo 'Error Inesperado';
	}





 ?>