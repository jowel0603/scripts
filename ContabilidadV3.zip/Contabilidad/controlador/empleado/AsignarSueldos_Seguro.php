<?php
	require_once '../../modelos/empleado/mdlEmpleado.php';
	try 
	{
		$filtros=$_POST['rut'];
		

		$miModelempleado = new ModeloEmpleado();
			
		$buscar=$miModelempleado->Buscar_Rut_empleado_Asignacion_Sueldo($filtros);

		if($buscar->rowCount() > 0) { 

			while($resultado=$buscar->fetch(PDO::FETCH_ASSOC))
			{
				$resultado['idempleado'] = $resultado['idempleado'];
				$resultado['rut'] = $resultado['rut'];
                $resultado['nombres'] = $resultado['nombres'];
                    
                echo json_encode($resultado);
			}
			 	//$row = $buscar->fetch(PDO::FETCH_ASSOC);
		} // if num_rows
		else
		{
			echo "No hay Resultados Consultados :( ";
			header("HTTP/1.0 404 Not Found");
		}





	} 
	catch (Exception $e) 
	{
		echo "Error ----> ".$e->getMessage();
	}
	catch (PDOException $ex)
	{
		   echo "Error Al Obtener AsignarSueldos_Seguro Controller ------> ".$ex->getMessage();
	}

 ?>