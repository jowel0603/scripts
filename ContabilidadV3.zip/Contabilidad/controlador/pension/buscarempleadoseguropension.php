<?php 

	
			$filtros=$_POST['rut'];
			require_once '../../modelos/empleado/mdlEmpleado.php';

			$miModelempleado = new ModeloEmpleado();
			
			$buscar=$miModelempleado->Buscarempleado($filtros);
			

			if($buscar->rowCount() > 0) { 

				while($resultado=$buscar->fetch(PDO::FETCH_ASSOC)){
					$resultado['idempleado'] = $resultado['idempleado'];
					$resultado['rut'] = $resultado['rut'];
                    $resultado['nombres'] = $resultado['nombres'];
                    $resultado['apellidos'] = $resultado['apellidos'];

                    echo json_encode($resultado);
				}
			 	//$row = $buscar->fetch(PDO::FETCH_ASSOC);

			 	
			} // if num_rows

			

			
		


 ?>