<?php
if($_SERVER['REQUEST_METHOD'] == 'POST'){

	if (!empty($_POST['ingUsuario']) && !empty($_POST['ingPassword'])) {
		# code...
	

			$users =  htmlspecialchars(trim($_POST['ingUsuario']));
			$clave = sha1($_POST['ingPassword']);
			

				require_once '../../modelos/Usuarios/mdlUsuarios.php';
				$miModelusuarios = new  ModeloUsuarios();

				$data = $miModelusuarios->verificarUsuariologin($users,$clave);


				if($num = $data->rowCount() == 1){
		      
		            $existe= $data->fetch();

		              $perfil = $existe["nombre_rol"];
		        	  $usuario = $existe["usuario"];
		        	  $idusuario=$existe["idrol"];
		        	  $id = $existe["id"];

		        	  $estado = $existe["estado"];


		            if($perfil == 'Administrador' && $estado == 1 || $perfil == 'Administrador S' && $estado == 1 || $perfil == 'Umbrella' && $estado == 1 || $perfil == 'Secretaria' && $estado == 1 ){


			            session_start();
			            $_SESSION["iniciarSesion"] = "ok";
			            $_SESSION['nombre_rol']=$perfil;
			            $_SESSION['usuario']=$usuario;
			            $_SESSION["idrol"] = $idusuario;
			            $_SESSION["id"] = $id;


				        require_once '../../modelos/Usuarios/mdlUsuarios.php';



		                $marcados = $miModelusuarios->listarmarcados($id);


		                //declaramos el array para almacenar todos los permisos
		                $valores=array();

		                //almacenamos los permisos marcados en al array
		                while ($per = $marcados->fetch(PDO::FETCH_OBJ)) {
		                  array_push($valores, $per->idtipopermiso);
		                }


		                //determinamos lo accesos al usuario
		                in_array(1, $valores)?$_SESSION['Empleados']=1:$_SESSION['Empleados']=0;
		                in_array(2, $valores)?$_SESSION['Empresas']=1:$_SESSION['Empresas']=0;
		                in_array(3, $valores)?$_SESSION['Sueldos']=1:$_SESSION['Sueldos']=0;
		                in_array(4, $valores)?$_SESSION['Seguro Pension']=1:$_SESSION['Seguro Pension']=0;
		                in_array(5, $valores)?$_SESSION['Seguro Salud']=1:$_SESSION['Seguro Salud']=0;
		                in_array(6, $valores)?$_SESSION['Usuarios']=1:$_SESSION['Usuarios']=0;
		                in_array(7, $valores)?$_SESSION['Reporte Balance']=1:$_SESSION['Reporte Balance']=0;
		                in_array(8, $valores)?$_SESSION['Reporte Diarios']=1:$_SESSION['Reporte Diarios']=0;
		                in_array(9, $valores)?$_SESSION['Reporte Mayor']=1:$_SESSION['Reporte Mayor']=0;
		                in_array(10, $valores)?$_SESSION['Periodo Contable']=1:$_SESSION['Periodo Contable']=0;
		                in_array(11, $valores)?$_SESSION['Plan Cuenta']=1:$_SESSION['Plan Cuenta']=0;
		                in_array(12, $valores)?$_SESSION['Contabilidad']=1:$_SESSION['Contabilidad']=0;
		                in_array(13, $valores)?$_SESSION['Diarios']=1:$_SESSION['Diarios']=0;
		                in_array(14, $valores)?$_SESSION['Asientos Contables']=1:$_SESSION['Asientos Contables']=0;
		                in_array(15, $valores)?$_SESSION['Dashboard']=1:$_SESSION['Dashboard']=0;

		              	echo '<script>alert("Bienvenido Sr(a) '.$perfil.'");</script>';
		            	echo '<script>window.location.href = "../../vistas/cpanel/cpanel.php";</script>';
		            }else{
		            	echo '<script>window.history.back()</script>';
		             	echo '<script>alert("Usuario no esta activado");</script>';
		         	}
		            
		            

		            
							
		         }else{
		         	 echo '<script>window.history.back()</script>';
		             echo '<script>alert("Usuario no existe");</script>';
		         }




		         $data = null;

		       }else{
		       		 echo '<script>window.history.back()</script>';
		             echo '<script>alert("Ingrese Usuario y clave  :D");</script>';
		       }
		                 
		    	


		}else{
			echo '<script>alert("Hubo un error inesperado");
		             window.history.back();</script>';
		}