<?php 

	//llamo al modelo usuarios
	require_once '../../modelos/usuarios/mdlUsuarios.php';

	//instansio la clase modelo usuarios
	$miModelusuario = new ModeloUsuarios();

	//llamo a la funcion cerrarseccion
	$cerrar = $miModelusuario->Cerrar_Seccion();

 ?>