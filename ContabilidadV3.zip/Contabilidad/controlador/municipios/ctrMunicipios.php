<?php
//modelo municipio
require_once '../../modelos/municipio/mdlMunicipio.php';


$departamento=$_POST["cod_dpto"];
//realizamos la instancia al modelo para obtener los datos
//
$miModelmunicipio = new ModeloMunicipio();
$obtenerdatos = $miModelmunicipio->getMunicipio($departamento);

if ($obtenerdatos->rowCount() > 0) {
	# code...
	while($row = $obtenerdatos->fetch()){
		echo "<option value=\"{$row["cod_mpio"]}\">{$row["nombre_mpio"]}</option>";
	}
}

?>