<?php
//modelo municipio
require_once '../../modelos/seguro/mdlSeguro.php';


$cargo=$_POST["cargo"];
//realizamos la instancia al modelo para obtener los datos
//
$miModelsueldo = new ModeloSeguro();
$obtenerdatos = $miModelsueldo->getSueldoempleado($cargo);

if ($obtenerdatos->rowCount() > 0) {
	# code...
	while($row = $obtenerdatos->fetch()){
		echo '<input readonly="" type="text" name="sueldo" id="sueldo" value="'.$row["sueldo"].'" class="form-control">';

	}
}

?>