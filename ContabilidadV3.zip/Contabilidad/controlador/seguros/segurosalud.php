<?php 
	sleep(1);
if ($_SERVER['REQUEST_METHOD'] == 'POST') {



	if(!empty($_POST["codigo"]) && !empty($_POST["nombre"]) && !empty($_POST["valor"]) && !empty($_POST["idempleado"]) && !empty($_POST["idusuario"])  ){

		
		if(strlen($_POST["valor"]) >= 1 && strlen($_POST["valor"]) == 1 || strlen($_POST["valor"]) >= 2 && strlen($_POST["valor"]) == 2){

				  


    				require_once '../../funciones/funciones.php';
  				

			    	$codigo=$_POST["codigo"];
				    $nombre=htmlspecialchars(addslashes($_POST["nombre"]));
				    $valor=intval($_POST["valor"]);
				    $idempleado=intval($_POST["idempleado"]);
				    $usuario=intval($_POST["idusuario"]);
				    $fecha = gmdate('Y-m-d H:i:s', hora_local(-5));

				    	require_once "../../modelos/seguro/mdlSeguro.php";

				    	$miSeguro = new ModeloSeguro();


				    	$verificar = $miSeguro->verificarcodigoseguro($codigo);

				    	if ($verificar->rowCount() > 0) {
			                # code...
			               	echo 'error2';
			               	return false;
			                
			                
			            }else{

			            	 $registroseguro = $miSeguro::mdlIngresarsegurosalud($codigo, $nombre,$valor,$idempleado,$usuario, $fecha);

						    if($registroseguro == 'ok'){
						    	echo $registroseguro;
						    }else if($registroseguro == 'error'){
						    	echo $registroseguro;
						    }
			            }


					}else{
						echo 8;
					}
			            	
			            



		}else{
			echo 9;
		}
			           

		
	}else{
		echo 'Error Inesperado';
	}





 ?>