<?php 
require_once '../include/head/head.php'; 

if ($_SESSION["Plan Cuenta"] == 1) {


?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>PUC</h1>
                
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="../cpanel/cpanel.php">Home</a></li>
              <li class="breadcrumb-item active">DataTables</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>


    <section class="content-header">
        <div class="col-12">
          <div class="card">
            






            
                  
              <section class="content-header">
                      <div class="content-header">
                          <div class="table-wrapper">
                            <div class="table-title">
                                <div class="row">
                                    <div class="col-sm-6">
                                      
                                    </div>
                                  <div class="col-sm-6" style="position: absolute; margin-top: 35px; padding-top: 20px;">
                                    
                                  </div>
                                </div>
                            </div>
                            <div class='col-sm-4 pull-right'>


                                <div id="custom-search-input">
                                    <div class="input-group col-md-12">
                                        <input type="text" class="form-control" placeholder="Buscar datos  "  id="q" onkeyup="load(1);" autocomplete="off" />
                                        <span class="input-group-btn">
                                            <button class="btn btn-info" type="button" onclick="load(1);">
                                              <i class="fa fa-search"></i>
                                            </button>
                                        </span>
                                    </div>
                                  </div>
                            </div>

                            <div class='clearfix'></div>
                            <hr>
                            <div id="loader"></div><!-- Carga de datos ajax aqui -->
                            <div id="resultados"></div><!-- Carga de datos ajax aqui -->


                              <!--<div style="display: none; text-align: center;" class="form-group d-none" id="gif">
                                <label><img src="../imagenes/ajax-loader.gif"> Procesando...</label>
                              </div>-->


                            <div class='outer_div'></div><!-- Carga de datos ajax aqui -->
                              
                        
                          </div>
                      </div>

                     




                  </section>
              



         </div>
        <!-- /.col -->
    </section>
    <!-- /.content -->
  </div>

<?php 


}else{
  include '../include/noacceso.php';
}
 ?>

 <?php 
require_once '../include/footer/footer.php'; ?>
 <script src="../scripts/asientoscontables.js"></script>  