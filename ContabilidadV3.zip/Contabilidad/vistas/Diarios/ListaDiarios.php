<?php 
require_once '../include/head/head.php'; 

  if ($_SESSION["Diarios"] == 1) {

?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Diarios</h1>
                 <a href="#myModalsueldo" class="btn btn-info" data-toggle="modal"><i class="fa fa-user"></i> <span>Agregar nuevo Diario</span></a>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="../cpanel/cpanel.php">Home</a></li>
              <li class="breadcrumb-item active">DataTables</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>


    <section class="content-header">
        <div class="col-12">
          <div class="card">
            






            
                  
              <section class="content-header">
                      <div class="content-header">
                          <div class="table-wrapper">
                            <div class="table-title">
                                <div class="row">
                                    <div class="col-sm-6">
                                      
                                    </div>
                                  <div class="col-sm-6" style="position: absolute; margin-top: 35px; padding-top: 20px;">
                                    
                                  </div>
                                </div>
                            </div>
                            <div class='col-sm-4 pull-right'>


                                <div id="custom-search-input">
                                    <div class="input-group col-md-12">
                                        <input type="text" class="form-control" placeholder="Buscar datos  "  id="q" onkeyup="load(1);" autocomplete="off" />
                                        <span class="input-group-btn">
                                            <button class="btn btn-info" type="button" onclick="load(1);">
                                              <i class="fa fa-search"></i>
                                            </button>
                                        </span>
                                    </div>
                                  </div>
                            </div>

                            <div class='clearfix'></div>
                            <hr>
                            <div id="loader"></div><!-- Carga de datos ajax aqui -->
                            <div id="resultados"></div><!-- Carga de datos ajax aqui -->


                              <!--<div style="display: none; text-align: center;" class="form-group d-none" id="gif">
                                <label><img src="../imagenes/ajax-loader.gif"> Procesando...</label>
                              </div>-->


                            <div class='outer_div'></div><!-- Carga de datos ajax aqui -->
                              
                        
                          </div>
                      </div>

                     




                  </section>



                  <!-- The Modal -->
                <div class="modal" id="myModalsueldo">
                  <div class="modal-dialog">
                    <div class="modal-content">

                      <!-- Modal Header -->
                      <div class="modal-header">
                        <h4 class="modal-title">Formulario Diario</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        
                      </div>
                      <div id="msg">
                          
                      </div>

                      <!-- Modal body -->
                      <div class="modal-body">
                        <form id="addDiario" name="addDiario" class="form-horizontal"  >
                          <input type="hidden" class="form-control" id="idusuario" name="idusuario" value="<?php echo $_SESSION["id"];  ?>" >
                                


                                <div class="form-group">
                                    <label for="sueldo" class="col-sm-3 control-label">Codigo</label>

                                    <div class="col-md-12">
                                      <input type="text" class="form-control" id="codigo"  name="codigo" autocomplete="off" >
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="perfil" class="col-sm-3 control-label">Nombre</label>
                                    <div class="col-md-12">
                                      <input type="text" id="nombre" name="nombre" placeholder="Digite nuevo diario" autocomplete="off" class="form-control">
                                    </div>
                                </div>
                                
                                
                                
                                
                                
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                              <button type="submit" class="btn btn-primary btn-flat btnGuardardiario"><i class="fa fa-save"></i> Guardar</button>
                              
                            </div>


                            </form>

                      

                    </div>
                  </div>
                </div>

              



         </div>
        <!-- /.col -->
    </section>
    <!-- /.content -->
  </div>

<?php 


}else{
  include '../include/noacceso.php';
}

 require_once '../include/footer/footer.php';
 ?>
 <script src="../scripts/diarios.js"></script>  