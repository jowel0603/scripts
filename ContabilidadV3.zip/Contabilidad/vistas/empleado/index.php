<?php require_once '../include/head/head.php'; 
 
  if ($_SESSION["Empleados"] == 1) {

?>
<!-- Main content -->
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 id="titulo">Listado de Empleado</h1>
             <h1 id="titulo2">Formulario de Empleado</h1>
            <button class="btn btn-primary ocultar" onclick="mostrarform(true)"><i class="fa fa-plus-circle"></i>Agregar</button></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="../cpanel/cpanel.php">Home</a></li>
              <li class="breadcrumb-item active">DataTables</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
     
           <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title"></h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body" id="form-ocultar">
              <table id="empleadotable" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Nombres</th>
                  <th>Apellidos</th>
                  <th>Rut</th>
                  <th>Celular</th>
                  <th>Telefono</th>
                  <th>Direccion</th>
                  <th>Genero</th>
                  <th>Empresa</th>
                  <th>Sucursal</th>
                  <th>Acciones</th>
                </tr>
                </thead>
                <tbody>
                  <?php 

                  require_once '../../modelos/empleado/mdlEmpleado.php';
                  $miEmpleado = new ModeloEmpleado();
                  $empleadodatos = $miEmpleado->Empleado($_SESSION["id"]);
                  foreach ($empleadodatos as $key => $value){


                 ?>
                <tr>
                  <td><?php echo $value['nombres'] ?></td>
                  <td><?php echo $value['apellidos'] ?>
                  </td>
                  <td><?php echo $value['rut'] ?>
                  </td>
                  <td><?php echo $value['celular'] ?></td>
                  <td><?php echo $value['telefono'] ?></td>
                  <td><?php echo $value['direccion'] ?></td>
                  <td><?php echo $value['genero'] ?></td>
                  <td><?php echo $value['nombre'] ?></td>
                  <td><?php echo $value['idsucursal'] ?></td>
                  <td><button class="btn btn-success btn-sm edit btn-flat" data-id="<?php echo $value['idempleado']; ?>"><i class="fa fa-edit"></i> Editar</button></td>
                </tr>
                <?php } ?>
                </tbody>
                <tfoot>
                <tr>
                  <th>Nombres</th>
                  <th>Apellidos</th>
                  <th>Rut</th>
                  <th>Celular</th>
                  <th>Telefono</th>
                  <th>Direccion</th>
                  <th>Genero</th>
                  <th>Empresa</th>
                  <th>Sucursal</th>
                  <th>Acciones</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.card-body -->


            <div class="card-body" id="formularioregistros">
              <div id="msg" class="alert-success">
                
              </div>
             
                 <form  name="formularioempleado" id="formularioempleado" >
                    
                        <input type="hidden" name="usuario" id="usuario" value="<?php  echo $_SESSION["id"]; ?>">
                        <div class="row">
                          <div class="col-md-6">
                            <div class="form-group">
                              <label>Nombres: *</label>
                              <input type="text" name="nombres" id="nombres" class="form-control" placeholder="Digite Nombres Del Empleado" autocomplete="off">
                            </div>
                            <!-- /.form-group -->
                            <div class="form-group">
                              <label>Rut: *</label>
                              <input type="text" name="rut" id="rut" class="form-control" placeholder="Digite Rut Del Empleado" autocomplete="off" maxlength="13" oninput="checkRut(this)">
                            </div>
                            <!-- /.form-group -->
                          </div>

                          <div class="col-md-6">
                             <div class="form-group">
                              <label>Apellidos: *</label>
                              <input type="text" name="apellidos" id="apellidos" class="form-control" placeholder="Digite Apellidos Del Empleado" autocomplete="off">
                            </div>
                            <!-- /.form-group -->
                            <div class="form-group">
                              <label>Celular: *</label>
                              <input type="text" name="celular" id="celular" class="form-control" placeholder="Digite Celular Del Empleado" autocomplete="off">
                            </div>

                            
                            <!-- /.form-group -->
                          </div>


                          <div class="col-md-6">
                            <div class="form-group">
                              <label>Direccion: *</label>
                              <input type="text" name="direccion" id="direccion" class="form-control" placeholder="Digite Direccion Del Empleado" autocomplete="off">
                            </div>
                            
                            <!-- /.form-group -->
                              <div class="form-group">
                              <label>Genero: *</label>
                              <select class="form-control select2" id="genero" name="genero" style="width: 100%;">
                                <option selected="selected">Sleccione un Genero</option>
                                <option value="Hombre">Hombre</option>
                                <option value="Mujer">Mujer</option>
                              </select>
                            </div>
                            <!-- /.form-group -->
                          </div>



                          <!-- /.col -->
                          <div class="col-md-6">

                            <div class="form-group">
                              <label>Telefono: *</label>
                              <input type="text" name="telefono" id="telefono" class="form-control" placeholder="Digite Direccion Del Empleado" autocomplete="off">
                            </div>
                           
                            
                             <!-- /.col -->
                        
                            <div class="form-group">
                              <label>Departamento: *</label>
                              <select class="form-control select2" name="cod_dpto" id="cod_dpto" style="width: 100%;">
                                <option selected="selected" >Sleccione un Departamento</option>
                                <?php


                                    require_once '../../modelos/departamentos/mdlDepartamentos.php';

                                    $miModelodpto = new ModeloDepartamento();
                                    $obtenerselectdatosdpto = $miModelodpto->Departamento();


                                    foreach ($obtenerselectdatosdpto as $key => $data3) {
                                      # code...
                                      # 
                                      echo '<option value="'.$data3["cod_dpto"].'">'.$data3["nombre_dpto"].'</option>';

                                      }
                                ?>
                              </select>
                            </div>


                           
                          
                          </div>
                          <!-- /.col -->
                          <div class="col-md-6">
                         

                            <!--<div class="form-group">
                              <label>Pais: *</label>
                              <select class="form-control select2" id="pais" name="pais" style="width: 100%;">
                                <option selected="selected">Sleccione un Pais</option>
                                <?php


                                    require_once '../../modelos/pais/mdlPais.php';

                                    $miModelopais = new ModeloPais();
                                    $obtenerselectdatospais = $miModelopais->Pais();


                                    foreach ($obtenerselectdatospais as $key => $data2) {
                                      # code...
                                      # 
                                      echo '<option value="'.$data2["id"].'">'.$data2["nombre"].'</option>';

                                      }
                                ?>
                              </select>
                            </div>-->

                            <div class="form-group">
                              <label>Empresa: *</label>
                              <select class="form-control select2" id="empresa" name="empresa" style="width: 100%;">
                                <option selected="selected">Sleccione una Empresa</option>
                                <?php


                                    require_once '../../modelos/empresa/mdlEmpresa.php';

                                    $miModeloempresa = new ModeloEmpresa();
                                    $obtenerselectdatosempresa = $miModeloempresa->Empresas($_SESSION["id"]);


                                    foreach ($obtenerselectdatosempresa as $key => $data2) {
                                      # code...
                                      # 
                                      echo '<option value="'.$data2["idempresa"].'">'.$data2["nombre"].'</option>';

                                      }
                                ?>
                              </select>
                            </div>

                          <!--  <div class="form-group">
                              <label>Sueldo: *</label>
                                <input readonly="" type="text" name="sueldo" id="sueldo" class="form-control">
                            </div>-->
                          </div>

                           <!-- /.col -->
                          <div class="col-md-6">

                            <div class="form-group">
                              <label>Sucursal: *</label>
                              <select class="form-control select2"  name="cod_mun" id="cod_mun" style="width: 100%;">
                                <option selected="selected" >Sleccione un Municipio</option>
                                
                              </select>
                            </div>



                          <!--  <div class="form-group">
                              <label>Cargo: *</label>
                              <select class="form-control select2" id="cargo" name="cargo" style="width: 100%;">
                                <option selected="selected">Sleccione un Cargo</option>
                                <?php


                                    require_once '../../modelos/ocupacion/mdlOcupacion.php';

                                    $miModelocupaciones = new ModeloOcupacion();
                                    $obtenerselectdatos = $miModelocupaciones->Ocupacion();


                                    foreach ($obtenerselectdatos as $key => $data) {
                                      # code...
                                      # 
                                      echo '<option value="'.$data["id_ocup"].'">'.$data["ocupacion"].'</option>';

                                      }
                                ?>
                              </select>
                            </div>-->


                           <!-- <div class="form-group">
                              <label>Sucursal: *</label>
                              <select class="form-control select2" style="width: 100%;">
                                <option selected="selected">Sleccione un Sucursal</option>
                                <option value="Hombre">Hombre</option>
                                <option value="Mujer">Mujer</option>
                              </select>
                            </div>-->
                            
                          </div>
                          <!-- /.col -->


                          <!-- /.col -->
                          <div class="col-md-6">
                            
                            <!-- /.form-group -->
                            
                            <!-- /.form-group -->
                            
                          </div>
                          <!-- /.col -->


                        </div>
                        <!-- /.row -->
                      
                  


                    <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
                      <button class="btn btn-primary" type="submit" ><i class="fa fa-save"></i>  Guardar</button>

                      <button class="btn btn-danger" onclick="cancelarform()" type="button"><i class="fa fa-arrow-circle-left"></i> Cancelar</button>
                    </div>
                  </form>
                
            </div>





     	   </div><!-- /.box -->
         </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>




<script src="../scripts/empleado.js"></script>

<?php 
}else{
	include '../include/noacceso.php';
}

 require_once '../include/footer/footer.php';
 ?>

