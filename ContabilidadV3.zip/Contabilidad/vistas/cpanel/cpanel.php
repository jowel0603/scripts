<?php require_once '../include/head/head.php'; 



   if ($_SESSION['Dashboard'] == 1){ 


    require_once '../../modelos/empresa/mdlEmpresa.php';

    $mdlEmpresa = new ModeloEmpresa();

    $conf = $mdlEmpresa->mdlMostrarConigEmpresa();

    if ($conf->rowCount() > 0) {
      # code...
    
?>


<!-- Main content -->

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Dashboard v1</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

  
          <!-- /.Left col -->
  <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-info">
              <div class="inner">
                <h3>150</h3>

                <p>New Orders</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <h3>53<sup style="font-size: 20px">%</sup></h3>

                <p>Bounce Rate</p>
              </div>
              <div class="icon">
                <i class="ion ion-stats-bars"></i>
              </div>
              <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
                <h3>44</h3>

                <p>User Registrations</p>
              </div>
              <div class="icon">
                <i class="ion ion-person-add"></i>
              </div>
              <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-danger">
              <div class="inner">
                <h3>65</h3>

                <p>Unique Visitors</p>
              </div>
              <div class="icon">
                <i class="ion ion-pie-graph"></i>
              </div>
              <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
        </div>
        <!-- /.row -->
        <!-- Main row -->
        <div class="row">
          <!-- Left col -->
     


          


          </div>
        <!-- /.row (main row) -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

 <?php  }else{



  ?>

  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <i class="fa fa-magic"></i><h1>Asistente </h1>
            <p>Para una mejor esperiencia actualiza tus datos de la empresa </p>
                 
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="../cpanel/cpanel.php">Home</a></li>
              <li class="breadcrumb-item active">DataTables</li>

            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <div id="MensajeExito" style="text-align: center; margin: 0px auto; padding: 0px auto;">
      
    </div>

    <div id="exito" name="exito"></div>
    <div id="error" name="error"></div>

    
    <div class="col-12">
      <section class="content-header">
        <div class="content-header">
          <div class="table-wrapper">

          <form name="formAddEmpresaconfig" id="formAddEmpresaconfig">

          <input type="hidden" name="idusuario" id="idusuario" value="<?php echo $_SESSION["id"]; ?>">

        <div class="nav-tabs-custom ">
         

          <div class="tab-content ">
            <div class="active tab-pane" id="activity">

             <div class="row">
              


              <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <label>Nombre(*):</label>
                <input type="text" class="form-control" name="nombre" id="nombre" maxlength="100" placeholder="Digite Nombre Completos"  autocomplete="off">
              </div>
              
              <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <label>Tipo Documento(*):</label>
                <select class="form-control select-picker" name="tipo_documento" id="tipo_documento" >
                  <option value="DNI">DNI</option>
                  <option value="RUT">RUC</option>
                  <option value="CC">CEDULA</option>
                </select>
              </div>
              
              <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                
                <label>Número(*):</label>
                
                <input type="text" class="form-control" name="num_documento" id="num_documento" maxlength="20" placeholder="Digite Numero de Documento"  autocomplete="off" onkeypress="return valideKey(event);" oninput="checkRut(this)">
              
              </div>
              
              <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                
                <label>Dirección:</label>
                
                <input type="text" class="form-control" name="direccion" id="direccion" placeholder="Digite Dirección" maxlength="70" autocomplete="off">
              
              </div>
              
              <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                
                <label>Teléfono:</label>
                
                <input type="text" class="form-control" name="telefono" id="telefono" maxlength="20" placeholder="Digite Teléfono" autocomplete="off" onkeypress="return valideKey(event);">
              
              </div>

                            
              
                <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                  
                  <label>Email:</label>
                  
                  <input type="text" class="form-control" name="email" id="email" maxlength="50" placeholder="Digite Email" autocomplete="off">
                
                </div>
              
                <!--<div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                  <label>Cargo:</label>
                  
                  <select name="cargo" id="cargo" class="form-control" >
                      <option value="">Seleccione un Perfil</option>
                      <?php 

                        require_once "../../modelos/Usuarios/mdlUsuarios.php"; 

                        //instancio el modelo
                        $usuario = new ModeloUsuarios();

                        $listarperfiles = $usuario->mdlRoles();

                        foreach ($listarperfiles as $key => $data3) {
                                                    # code...
                                                    # 
                            echo '<option value="'.$data3["idrol"].'">'.$data3["nombre_rol"].'</option>';

                        }

                      ?>  
                                    
                </select>
                
                </div>-->

              
                  <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    
                    <label>Celular:</label>
                    
                    <input type="text" class="form-control" name="celular" id="celular" maxlength="20" placeholder="Digite Celular" autocomplete="off" onkeypress="return valideKey(event);">
                  
                  </div>


              
                  <!--<div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    
                    <label>Estado:</label>
                      
                      <select name="estado" id="estado" class="form-control" >
                        
                        <option value="">Seleccione un Estado</option>
                        
                        <option value="1">Activo</option>
                        
                        <option value="0">Inactivo</option>
                      
                      </select>
                  
                  </div>

              </div>-->




                </div>




                                


                              
                <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
                  <button class="btn btn-primary" type="submit" id="btnGuardarEmpresaconfig"><i class="fa fa-save"></i> Guardar</button>

                   <button type="button" class="btn btn-danger" >Cancelar</button>
                </div>


                </div><!-- /.tab-content -->
              </div><!-- /.nav-tabs-custom -->

            </div><!-- fin row -->

          </form>

          </div>
        </div>
        
        </div>
      </section>
      






      </div>
    

         

  <?php

 } ?>
  <!-- fin footer -->
  <?php }else{
    include '../include/noacceso.php';
  } 

 require_once '../include/footer/footer.php';

   ?>
   <!-- footer -->
  <?php  ?>

  <script src="../scripts/configDatos.js" type="text/javascript"></script>