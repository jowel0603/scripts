<?php require_once '../include/head/head.php'; 
  if ($_SESSION["Empresas"] == 1) {


    require_once '../../modelos/empresa/mdlEmpresa.php';

    $mdlEmpresa = new ModeloEmpresa();

    $conf = $mdlEmpresa->mdlMostrarConigEmpresa();

    if ($conf->rowCount() > 0) {

      while($data = $conf->fetch(PDO::FETCH_ASSOC)){
          $empresa = $data["nombre_empresa"];
          $idconfig = $data["idconfig"];
          $tipodocumento = $data["tipodocumento"];
          $rut = $data["rut"];
          $email = $data["email"];
          $telefono = $data["telefono"];
          $celular = $data["celular"];
          $direccion = $data["direccion"];
      }

?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Datos De La Empresa</h1>
           
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="../cpanel/cpanel.php">Home</a></li>
              <li class="breadcrumb-item active">Datos De La Empresa</li>

            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <div id="MensajeExito" style="text-align: center; margin: 0px auto; padding: 0px auto;">
      
    </div>

    <div id="exito" name="exito"></div>
    <div id="error" name="error"></div>

    
    <div class="col-12">
      <section class="content-header">
        <div class="content-header">
          <div class="table-wrapper">

          <form name="formEditEmpresaconfig" id="formEditEmpresaconfig">

          <input type="hidden" name="idusuario" id="idusuario" value="<?php echo $_SESSION["id"]; ?>">
          <input type="hidden" name="idconfig" id="idconfig" value="<?php echo $idconfig; ?>">

        <div class="nav-tabs-custom ">
         

          <div class="tab-content ">
            <div class="active tab-pane" id="activity">

             <div class="row">
              


              <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <label>Nombre(*):</label>
                <input type="text" class="form-control" name="nombre" id="nombre" maxlength="100" placeholder="Digite Nombre Completos"  autocomplete="off" value="<?php echo $empresa; ?>">
              </div>
              
              <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <label>Tipo Documento(*):</label>
                <select class="form-control select-picker" name="tipo_documento" id="tipo_documento" >
                  <option value="DNI" <?php if ($tipodocumento == "DNI") echo "selected"; ?> >DNI</option>
                  <option value="RUT" <?php if ($tipodocumento == "RUT") echo "selected"; ?> >RUC</option>
                  <option value="CC" <?php if ($tipodocumento == "CC") echo "selected"; ?> >CC
                  
                </select>
              </div>
              
              <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                
                <label>Número(*):</label>
                
                <input type="text" class="form-control" name="num_documento" id="num_documento" maxlength="20" placeholder="Digite Numero de Documento"  autocomplete="off" onkeypress="return valideKey(event);" oninput="checkRut(this)" value="<?php echo $rut; ?>">
              
              </div>
              
              <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                
                <label>Dirección:</label>
                
                <input type="text" class="form-control" name="direccion" id="direccion" placeholder="Digite Dirección" maxlength="70" autocomplete="off" value="<?php echo $direccion; ?>">
              
              </div>
              
              <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                
                <label>Teléfono:</label>
                
                <input type="text" class="form-control" name="telefono" id="telefono" maxlength="20" placeholder="Digite Teléfono" autocomplete="off" onkeypress="return valideKey(event);" value="<?php echo $telefono; ?>" >
              
              </div>

                            
              
                <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                  
                  <label>Email:</label>
                  
                  <input type="text" class="form-control" name="email" id="email" maxlength="50" placeholder="Digite Email" autocomplete="off" value="<?php echo $email; ?>">
                
                </div>
              
                <!--<div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                  <label>Cargo:</label>
                  
                  <select name="cargo" id="cargo" class="form-control" >
                      <option value="">Seleccione un Perfil</option>
                      <?php 

                        require_once "../../modelos/Usuarios/mdlUsuarios.php"; 

                        //instancio el modelo
                        $usuario = new ModeloUsuarios();

                        $listarperfiles = $usuario->mdlRoles();

                        foreach ($listarperfiles as $key => $data3) {
                                                    # code...
                                                    # 
                            echo '<option value="'.$data3["idrol"].'">'.$data3["nombre_rol"].'</option>';

                        }

                      ?>  
                                    
                </select>
                
                </div>-->

              
                  <div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    
                    <label>Celular:</label>
                    
                    <input type="text" class="form-control" name="celular" id="celular" maxlength="20" placeholder="Digite Celular" autocomplete="off" onkeypress="return valideKey(event);" value="<?php echo $celular; ?>">
                  
                  </div>


              
                  <!--<div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    
                    <label>Estado:</label>
                      
                      <select name="estado" id="estado" class="form-control" >
                        
                        <option value="">Seleccione un Estado</option>
                        
                        <option value="1">Activo</option>
                        
                        <option value="0">Inactivo</option>
                      
                      </select>
                  
                  </div>

              </div>-->




                </div>




                                


                              
                <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
                  <button class="btn btn-primary" type="submit" id="btnEditarEmpresaconfig"><i class="fa fa-save"></i> Actualizar</button>

                   <button type="button" class="btn btn-danger" >Cancelar</button>
                </div>


                </div><!-- /.tab-content -->
              </div><!-- /.nav-tabs-custom -->

            </div><!-- fin row -->

          </form>

          </div>
        </div>
        
        </div>
      </section>
      






      </div>




<?php
}else{

?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>No Tenemos Digitados Datos De Empresa</h1>
           
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="../cpanel/cpanel.php">Home</a></li>
              <li class="breadcrumb-item active">Datos De La Empresa</li>

            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>


</div>
<?php
} ?>
<?php 
}else{
  include '../include/noacceso.php';
}

 require_once '../include/footer/footer.php';
 ?>

 <script src="../scripts/configDatos.js" type="text/javascript"></script>