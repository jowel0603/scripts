<?php require_once '../include/head/head.php'; 
  if ($_SESSION["Empresas"] == 1) {

?>
<!-- Main content -->
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Listado de Empresas</h1>
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
              Añadir Empresa
            </button>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="../cpanel/cpanel.php">Home</a></li>
              <li class="breadcrumb-item active">DataTables</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
     
           <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title"></h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Empresa</th>
                  <th>RUT</th>
                  <th>Dirección</th>
                  <th>Telefono</th>
                  <th>Celular</th>
                  <th>Email</th>
                  <th>Acciones</th>
                </tr>
                </thead>
                <tbody>
                  <?php 

                  require_once '../../modelos/empresa/mdlEmpresa.php';
                  $miEmpresa = new ModeloEmpresa();
                  $empresadatos = $miEmpresa->Empresas($_SESSION["id"]);
                  foreach ($empresadatos as $key => $value){


                 ?>
                <tr>
                  <td><?php echo $value['nombre'] ?></td>
                  <td><?php echo $value['nit'] ?>
                  </td>
                  <td><?php echo $value['direccion'] ?></td>
                  <td><?php echo $value['telefono'] ?></td>
                  <td><?php echo $value['celular'] ?></td>
                  <td><?php echo $value['correo'] ?></td>
                  <td><button class="btn btn-success btn-sm edit btn-flat" data-id="<?php echo $value['idempresa']; ?>"><i class="fa fa-edit"></i> Editar</button></td>
                </tr>
                <?php } ?>
                </tbody>
                <tfoot>
                <tr>
                  <th>Empresa</th>
                  <th>RUT</th>
                  <th>Dirección</th>
                  <th>Telefono</th>
                  <th>Celular</th>
                  <th>Email</th>
                  <th>Acciones</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.card-body -->
     	   </div><!-- /.box -->
         </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>


<?php 
include '../modal/empresa_modal.php';

 ?>

<script src="../scripts/empresa.js"></script>


	
<?php 
}else{
	include '../include/noacceso.php';
}

 require_once '../include/footer/footer.php';
 ?>

