<?php
/*
| -----------------------------------------------------
| PROYECTO:         CONTABILIDAD
| -----------------------------------------------------
| AUTOR:            jhon valencia
| -----------------------------------------------------
| FACEBOOK:         
| -----------------------------------------------------
| COPYRIGHT:        
| -----------------------------------------------------
| WEBSITE:          
| -----------------------------------------------------
*/
Class Connection{
  
   
  
    
    protected $conn;
     
    public function open(){
        try{
            $this->conn = new PDO("mysql:host=localhost;dbname=contabilidadchilena", "root", "");
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $this->conn->exec("set names utf8");
            return $this->conn;
        }
        catch (PDOException $e){
            echo "Ocurrió un problema con la conexión: " . $e->getMessage();
        }
  
    }
  
    public function close(){
        $this->conn = null;
    }
  
}