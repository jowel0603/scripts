<?php 


	function hora_local($zona_horaria = 0){
	if ($zona_horaria > -12.1 and $zona_horaria < 12.1)
	{
		$hora_local = time() + ($zona_horaria * 3600);
		return $hora_local;
	}
	return 'error';
	}


	function cambiafamysql($fecha){
		if(!empty($fecha)){
			list($dia,$mes,$anio)=explode("/",$fecha);
	    	$lafecha=$anio."-".$mes."-".$dia;
	    	return $lafecha;
		}
	}



	define ("CLAVE", "m._cl22@ddDPZ_ffDcc1!23ss");
 
	//Para generar una URL segura para el método GET
	function generaURLSegura ($metodo, $valor)
	{
	  return $metodo . "=" . md5(CLAVE . $valor);
	}


	// funcion para validar clave
	function validar_clave($clave){
	   if(strlen($clave) < 6){
	     
	      return false;
	   }
	   if(strlen($clave) > 16){
	     
	      return false;
	   }
	   if (!preg_match('`[a-z]`',$clave)){
	     
	      return false;
	   }
	   if (!preg_match('`[A-Z]`',$clave)){
	     
	      return false;
	   }
	   if (!preg_match('`[0-9]`',$clave)){
	     
	      return false;
	   }
	   return true;
	}
	


 ?>